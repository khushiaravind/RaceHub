import { useState, useEffect } from "react";
import { TrackData, TRACKS, F1Team } from "../types";
import { Map, Trophy, Compass, Tag } from "lucide-react";

interface TrackMapProps {
  selectedTrack: TrackData;
  onSelectTrack: (track: TrackData) => void;
  activeTeam: F1Team;
  currentSpeed: number;
  carPositionIndex: number;
}

export default function TrackMap({ selectedTrack, onSelectTrack, activeTeam, currentSpeed, carPositionIndex }: TrackMapProps) {
  const points = selectedTrack.racingLinePoints;
  const currentCarPoint = points[carPositionIndex] || points[0] || { x: 250, y: 250 };

  // Calculate sector ranges roughly based on points length
  const pointsLength = points.length;
  const s1End = Math.floor(pointsLength * 0.33);
  const s2End = Math.floor(pointsLength * 0.66);

  const getPointColor = (index: number) => {
    if (index < s1End) return "stroke-yellow-400"; // Sector 1
    if (index < s2End) return "stroke-emerald-400"; // Sector 2
    return "stroke-blue-400"; // Sector 3
  };

  // Build the SVG path string
  const dPath = points.reduce((acc, p, i) => {
    return acc + `${i === 0 ? "M" : "L"} ${p.x} ${p.y} `;
  }, "") + "Z";

  // Compute bounding box or use hardcoded scale
  // Points are generally designed around 500x500 box

  return (
    <div className="bg-black/85 backdrop-blur-xl rounded-xl p-5 border border-zinc-800/80 flex flex-col h-full overflow-hidden shadow-[0_4px_20px_rgba(0,0,0,0.5)] hover:border-red-500/10 transition-all" id="track-map-container">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Map className="w-4 h-4 text-red-500 animate-pulse" />
          <h2 className="text-xs font-black tracking-widest text-zinc-150 uppercase font-sans">
            Circuit Radar & GPS
          </h2>
        </div>
        <div className="flex bg-zinc-950 border border-zinc-900 rounded p-0.5 text-[10px]">
          {TRACKS.map((t) => (
            <button
              key={t.id}
              onClick={() => {
                onSelectTrack(t);
              }}
              className={`px-2 py-1 uppercase tracking-wider rounded transition-all duration-150 font-bold ${
                selectedTrack.id === t.id
                  ? "bg-red-600 text-white font-extrabold shadow-md shadow-red-950/40"
                  : "text-zinc-500 hover:text-zinc-300"
              }`}
              id={`track-${t.id}`}
            >
              {t.country}
            </button>
          ))}
        </div>
      </div>

      {/* Track Stats */}
      <div className="grid grid-cols-4 gap-2 mb-4">
        <div className="bg-zinc-950 border border-zinc-900 p-2 rounded flex flex-col shadow-inner">
          <span className="text-[8px] text-zinc-500 tracking-widest uppercase font-mono font-bold">Circuit ID</span>
          <span className="text-xs font-bold text-zinc-350 font-mono truncate uppercase mt-0.5">{selectedTrack.name}</span>
        </div>
        <div className="bg-zinc-950 border border-zinc-900 p-2 rounded flex flex-col shadow-inner">
          <span className="text-[8px] text-zinc-500 tracking-widest uppercase font-mono font-bold">Length</span>
          <span className="text-xs font-mono font-bold text-zinc-350 mt-0.5">{selectedTrack.length}</span>
        </div>
        <div className="bg-zinc-950 border border-zinc-900 p-2 rounded flex flex-col shadow-inner">
          <span className="text-[8px] text-zinc-500 tracking-widest uppercase font-mono font-bold">Turns</span>
          <span className="text-xs font-mono font-bold text-zinc-350 mt-0.5">{selectedTrack.turns}</span>
        </div>
        <div className="bg-zinc-950 border border-zinc-900 p-2 rounded flex flex-col shadow-inner">
          <span className="text-[8px] text-zinc-500 tracking-widest uppercase font-mono font-bold">Severity</span>
          <span className={`text-[11px] font-black uppercase mt-0.5 ${
            selectedTrack.difficulty === "Extreme" ? "text-red-500" :
            selectedTrack.difficulty === "High" ? "text-orange-500" : "text-emerald-450"
          }`}>{selectedTrack.difficulty}</span>
        </div>
      </div>

      {/* The Map Stage */}
      <div className="flex-1 relative bg-black/95 rounded border border-zinc-900 overflow-hidden min-h-[220px] flex items-center justify-center">
        {/* Ambient illumination behind map of the current team color */}
        <div 
          className="absolute inset-0 opacity-10 blur-3xl pointer-events-none transition-all duration-300 animate-pulse"
          style={{ backgroundColor: activeTeam.baseColor }}
        />

        {/* Sector Labels overlay */}
        <div className="absolute top-2 left-3 flex gap-3 text-[9px] uppercase tracking-wider font-mono font-bold">
          <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-yellow-450"></span>Sec 1</span>
          <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>Sec 2</span>
          <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-blue-400"></span>Sec 3</span>
        </div>

        <div className="absolute bottom-2 left-3 text-[8px] text-zinc-600 font-mono font-bold uppercase tracking-wider">
          CAR GPS POSITION: {carPositionIndex} / {pointsLength}
        </div>

        <svg viewBox="50 50 480 450" className="w-full h-full max-h-[300px] max-w-[400px]">
          {/* Track Shadow/Glow Base */}
          <path
            d={dPath}
            fill="none"
            stroke={activeTeam.baseColor}
            strokeWidth="10"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="opacity-15 blur-sm"
          />

          {/* Timing/Sector colors applied sequentially */}
          {points.map((p, i) => {
            if (i === points.length - 1) return null;
            const nextPoint = points[i + 1];
            return (
              <line
                key={i}
                x1={p.x}
                y1={p.y}
                x2={nextPoint.x}
                y2={nextPoint.y}
                className={`${getPointColor(i)} stroke-[4] hover:stroke-[6] transition-all duration-150 cursor-crosshair`}
              />
            );
          })}

          {/* Start Finish Line cross checker */}
          <g transform={`translate(${points[0].x}, ${points[0].y})`}>
            <rect x="-8" y="-2" width="16" height="4" fill="#ffffff" stroke="#000" strokeWidth="1" />
            <rect x="-8" y="-2" width="4" height="2" fill="#000000" />
            <rect x="0" y="-2" width="4" height="2" fill="#000000" />
            <rect x="-4" y="0" width="4" height="2" fill="#000000" />
            <text x="-25" y="15" className="fill-slate-500 text-[8px] font-mono select-none font-bold">START/FINISH</text>
          </g>

          {/* Dynamic glowing telemetry car indicator */}
          <g transform={`translate(${currentCarPoint.x}, ${currentCarPoint.y})`}>
            <circle
              r="12"
              className="fill-none animate-ping"
              style={{ stroke: activeTeam.baseColor, strokeWidth: 1 }}
            />
            <circle
              r="8"
              fill={activeTeam.baseColor}
              className="shadow-lg blur-[2px]"
            />
            <circle
              r="4"
              fill="#ffffff"
            />
          </g>

          {/* Additional telemetry annotation */}
          <g transform={`translate(${Math.max(50, currentCarPoint.x - 70)}, ${Math.max(50, currentCarPoint.y - 30)})`} className="pointer-events-none">
            <rect width="110" height="24" rx="4" fill="#000000" stroke={activeTeam.baseColor} strokeWidth="1.5" className="opacity-90 shadow-md" />
            <text x="6" y="15" fill="#ffffff" className="font-mono text-[9px] font-bold">
              CAR #{activeTeam.logoChar === "🐎" ? "16" : activeTeam.logoChar === "⚡" ? "4" : "1"} • {currentSpeed} KM/H
            </text>
          </g>
        </svg>
      </div>

      <div className="mt-4 bg-zinc-950/60 p-3 rounded border border-zinc-900 text-xs shadow-inner">
        <div className="flex items-center gap-2 text-zinc-300">
          <Trophy className="w-3.5 h-3.5 text-yellow-500" />
          <span className="font-extrabold text-[10px] text-zinc-400 uppercase tracking-wider font-mono">Optimum Run Strategy:</span>
        </div>
        <p className="mt-1.5 text-zinc-400 leading-relaxed text-[11px] font-medium">
          {selectedTrack.optimalStrategy}. Avoid heavy curbs through early corners to maximize tire life.
        </p>
      </div>
    </div>
  );
}

import { InsightItem } from "../types";
import { AlertTriangle, TrendingUp, HelpCircle, Activity, Hourglass } from "lucide-react";

interface InsightsFeedProps {
  insights: InsightItem[];
}

export default function InsightsFeed({ insights }: InsightsFeedProps) {
  
  const getInsightIcon = (type: string) => {
    switch (type) {
      case "warning":
        return <AlertTriangle className="w-3.5 h-3.5 text-red-500 shrink-0 mt-0.5 animate-pulse" />;
      case "performance":
        return <TrendingUp className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />;
      case "strategy":
        return <Hourglass className="w-3.5 h-3.5 text-yellow-500 shrink-0 mt-0.5 animate-spin" style={{ animationDuration: '4s' }} />;
      default:
        return <Activity className="w-3.5 h-3.5 text-blue-400 shrink-0 mt-0.5" />;
    }
  };

  const getInsightBg = (type: string) => {
    switch (type) {
      case "warning":
        return "bg-red-950/15 border-red-900/40 text-red-200";
      case "performance":
        return "bg-emerald-950/15 border-emerald-900/40 text-emerald-200";
      case "strategy":
        return "bg-yellow-950/15 border-yellow-900/40 text-yellow-200";
      default:
        return "bg-blue-950/15 border-blue-900/40 text-blue-200";
    }
  };

  return (
    <div className="bg-black/85 backdrop-blur-xl rounded-xl p-5 border border-zinc-800/80 flex flex-col h-full max-h-[350px] shadow-[0_4px_20px_rgba(0,0,0,0.5)] hover:border-red-500/10 transition-all" id="insights-feed-container">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-zinc-900/60 mb-3">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-red-500" />
          <h2 className="text-xs font-black tracking-widest text-zinc-150 uppercase font-sans">
            Pit Wall Live Insights Feed
          </h2>
        </div>
        <div className="flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping" />
          <span className="text-[9px] font-mono font-black text-zinc-500 uppercase tracking-widest">FEED LIVE</span>
        </div>
      </div>

      {/* Feed list */}
      <div className="flex-1 overflow-y-auto space-y-2 pr-1 scrollbar-thin scrollbar-thumb-zinc-850" id="live-feed-scroller">
        {insights.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-6 text-zinc-500">
            <span className="text-[9px] uppercase tracking-widest font-mono font-bold animate-pulse text-zinc-650">Telemetry link connecting...</span>
          </div>
        ) : (
          insights.map((item) => (
            <div
              key={item.id}
              className={`p-3 rounded border flex gap-2.5 transition-all duration-350 hover:bg-zinc-950 ${getInsightBg(
                item.type
              )}`}
              id={`insight-item-${item.id}`}
            >
              {getInsightIcon(item.type)}
              <div className="flex-1 min-w-0">
                <p className="text-[11px] font-sans font-medium leading-relaxed">{item.message}</p>
                <div className="flex items-center justify-between mt-1.5 border-t border-zinc-900/40 pt-1.5">
                  <span className="text-[8px] uppercase tracking-wider text-zinc-500 font-mono font-bold">
                    Source: AI Core Telemetry
                  </span>
                  <span className="text-[8px] text-zinc-500 font-mono italic font-bold">
                    {item.timestamp}
                  </span>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

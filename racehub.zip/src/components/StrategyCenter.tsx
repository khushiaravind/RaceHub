import { useState } from "react";
import { TelemetryState, F1Team, F1Driver, StrategyResult } from "../types";
import { Disc, Play, RefreshCw, BarChart2, ShieldCheck, TrendingUp } from "lucide-react";

interface StrategyCenterProps {
  telemetryState: TelemetryState;
  activeTeam: F1Team;
  activeDriver: F1Driver;
  onRunSimulation: () => void;
  strategyOutput: StrategyResult | null;
  isSimulating: boolean;
}

export default function StrategyCenter({
  telemetryState,
  activeTeam,
  activeDriver,
  onRunSimulation,
  strategyOutput,
  isSimulating,
}: StrategyCenterProps) {
  return (
    <div className="bg-black/85 backdrop-blur-xl rounded-xl p-5 border border-zinc-800/80 flex flex-col h-full shadow-[0_4px_20px_rgba(0,0,0,0.5)] hover:border-red-500/10 transition-all" id="strategy-center-container">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-zinc-900/60 mb-4">
        <div className="flex items-center gap-2">
          <Disc className="w-4 h-4 text-red-500 animate-spin" />
          <h2 className="text-xs font-black tracking-widest text-zinc-150 uppercase font-sans">
            Tire Strategy Center
          </h2>
        </div>
        <span className="text-[9px] text-zinc-400 font-mono font-black bg-zinc-950 px-2 py-0.5 rounded border border-zinc-900 tracking-wider">
          PIT WINDOW L22-28
        </span>
      </div>

      {/* Main interactive state parameters */}
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="bg-zinc-950 border border-zinc-900 p-3 rounded flex flex-col justify-between shadow-inner">
          <span className="text-[8px] text-zinc-500 uppercase font-mono tracking-widest font-bold">Active Compound</span>
          <div className="flex items-center gap-2 mt-1.5">
            <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-black text-black ${
              telemetryState.tireCompound === "Soft" ? "bg-red-500" :
              telemetryState.tireCompound === "Medium" ? "bg-yellow-500" :
              telemetryState.tireCompound === "Hard" ? "bg-white" : "bg-blue-500"
            }`}>
              {telemetryState.tireCompound[0]}
            </span>
            <span className="text-xs font-bold text-slate-200">{telemetryState.tireCompound}</span>
          </div>
          <span className="text-[9px] text-zinc-500 font-mono mt-1.5 font-bold uppercase">{telemetryState.tireAge} Laps / Wear {Math.round(telemetryState.tireWear)}%</span>
        </div>

        <div className="bg-zinc-950 border border-zinc-900 p-3 rounded flex flex-col justify-between shadow-inner">
          <span className="text-[8px] text-zinc-500 uppercase font-mono tracking-widest font-bold">Remaining Life</span>
          <span className="text-sm font-extrabold font-mono text-zinc-300 mt-1.5 uppercase">
            {Math.max(1, Math.round(45 - telemetryState.tireAge))} Sectors
          </span>
          <span className="text-[9px] text-zinc-500 font-mono mt-1.5 font-bold uppercase">Grip Degradation Lock</span>
        </div>
      </div>

      {/* Recommended Strategy Preview prior to full simulation trigger */}
      {strategyOutput ? (
        <div className="flex-1 space-y-3" id="strategy-simulation-output-display">
          {/* Main sequence recommendation */}
          <div className="bg-zinc-950/70 p-3 rounded border border-zinc-900 flex flex-col shadow-inner">
            <span className="text-[8px] text-zinc-500 uppercase font-mono font-black tracking-widest">Recommended Strategy Sequence</span>
            <div className="flex items-center gap-2 mt-2">
              {strategyOutput.compoundSequence.map((cmp, index) => (
                <div key={index} className="flex items-center gap-2">
                  <div className="flex items-center gap-1.5 bg-black px-2.5 py-1 rounded border border-zinc-900">
                    <span className={`w-2.5 h-2.5 rounded-full ${
                      cmp === "Soft" ? "bg-red-500" : cmp === "Medium" ? "bg-yellow-500" : "bg-white"
                    }`} />
                    <span className="text-[10px] font-bold text-zinc-350 font-mono uppercase">{cmp}</span>
                  </div>
                  {index < strategyOutput.compoundSequence.length - 1 && <span className="text-red-500 font-black text-xs">➔</span>}
                </div>
              ))}
            </div>
          </div>

          {/* Pit Windows details */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-zinc-950/40 p-2.5 rounded border border-zinc-900 flex flex-col justify-between">
              <span className="text-[8px] text-zinc-500 uppercase font-mono font-black tracking-widest">Primary Pit lap</span>
              <span className="text-xs font-mono font-extrabold text-zinc-300 mt-1">LAP {strategyOutput.recommendedLap}</span>
              <span className="text-[8px] text-emerald-400 font-bold uppercase tracking-wider mt-0.5">Finishing: P{strategyOutput.expectedFinishingPos}</span>
            </div>

            <div className="bg-zinc-950/40 p-2.5 rounded border border-zinc-900 flex flex-col justify-between">
              <span className="text-[8px] text-zinc-500 uppercase font-mono font-black tracking-widest">Alternative Pit</span>
              <span className="text-xs font-mono font-extrabold text-zinc-300 mt-1">LAP {strategyOutput.alternativeLap}</span>
              <span className="text-[8px] text-zinc-500 font-bold uppercase mt-0.5">FLEX STRATEGY</span>
            </div>
          </div>

          {/* Undercut / Overcut probabilities */}
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-emerald-950/15 p-2.5 rounded border border-emerald-950/30 flex flex-col justify-between">
              <span className="text-[8px] text-emerald-500 uppercase font-mono font-black tracking-widest">Undercut Advantage</span>
              <span className="text-xs font-mono font-black text-emerald-400 mt-1">-{strategyOutput.undercutLapDelta}s</span>
              <span className="text-[8px] text-zinc-550 font-medium uppercase mt-0.5">Time gain on outlap</span>
            </div>

            <div className="bg-blue-950/15 p-2.5 rounded border border-blue-950/30 flex flex-col justify-between">
              <span className="text-[8px] text-blue-400 uppercase font-mono font-black tracking-widest">Overcut Delta</span>
              <span className="text-xs font-mono font-black text-blue-300 mt-1">+{strategyOutput.overcutLapDelta}s</span>
              <span className="text-[8px] text-zinc-550 font-medium uppercase mt-0.5 font-sans">Staying on old tires</span>
            </div>
          </div>

          {/* Success probability indicator */}
          <div className="bg-zinc-950/90 p-2.5 rounded border border-zinc-900 flex items-center justify-between text-xs shadow-inner">
            <span className="font-extrabold text-[10px] text-zinc-400 uppercase tracking-widest inline-flex items-center gap-1 font-mono">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-500 animate-pulse" />
              Success Confidence
            </span>
            <span className="font-mono text-emerald-400 font-black text-xs bg-emerald-950/60 px-2.5 py-0.5 rounded border border-emerald-900/30 tracking-wider">
              {strategyOutput.successProbability}% MATCH
            </span>
          </div>
        </div>
      ) : (
        <div className="flex-1 flex flex-col justify-center items-center text-center p-6 border border-dashed border-zinc-800 rounded bg-zinc-950/30 shadow-inner">
          <BarChart2 className="w-6 h-6 text-zinc-800 mb-2 animate-pulse" />
          <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-wider">No active strategy simulation output.</p>
          <p className="text-[8px] text-zinc-550 mt-1 uppercase max-w-[200px] leading-relaxed font-semibold">
            Run a full tactical Monte Carlo simulation to plot tire sequences, undercut, and stop targets.
          </p>
        </div>
      )}

      {/* SIMULATION TRIGGER BUTTON */}
      <button
        onClick={onRunSimulation}
        disabled={isSimulating}
        className={`w-full mt-4 flex items-center justify-center gap-2 rounded py-2.5 text-[10px] font-black uppercase tracking-widest transition-all duration-300 border ${
          isSimulating
            ? "bg-zinc-950 border-zinc-900 text-zinc-500 cursor-not-allowed"
            : "bg-red-600 border-red-500 text-white hover:bg-red-500 shadow-md shadow-red-950/50"
        }`}
        id="btn-run-simulation"
      >
        {isSimulating ? (
          <>
            <RefreshCw className="w-3 h-3 animate-spin" />
            <span>CALCULATING PACING COMBINATORICS...</span>
          </>
        ) : (
          <>
            <Play className="w-3 h-3 fill-current" />
            <span>RUN TACTICAL SIMULATION</span>
          </>
        )}
      </button>
    </div>
  );
}

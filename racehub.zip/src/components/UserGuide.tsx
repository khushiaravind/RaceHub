import { useState } from "react";
import { BookOpen, ChevronDown, ChevronUp, Cpu, Info, HelpCircle } from "lucide-react";

interface GuideItem {
  id: string;
  code: string;
  title: string;
  description: string;
  metrics: string[];
  tips: string;
}

export default function UserGuide() {
  const [isOpen, setIsOpen] = useState(false);
  const [activeItem, setActiveItem] = useState<string | null>(null);

  const guideItems: GuideItem[] = [
    {
      id: "driver-center",
      code: "DRV-01",
      title: "Driver Center",
      description: "Manages the selected driver profiles, team contracts, and team rival comparison benchmarks.",
      metrics: [
        "Active driver classification details",
        "Team identity and hex color styling overrides",
        "Comparison telemetry toggle mode"
      ],
      tips: "Toggle the 'Comparison Mode' to overlay and benchmark your primary driver's lap histories directly against active rival metrics."
    },
    {
      id: "track-map",
      code: "TRK-02",
      title: "Interactive Track Map",
      description: "Generates high-resolution telemetry simulation mapping across world-class race circuits.",
      metrics: [
        "Real-time vehicle speed telemetry sync",
        "Circuit profile details and current corners count",
        "Active team speed indicators"
      ],
      tips: "Select different circuits from the dropdown menu to instantly adjust the pit-window telemetry calculations for different track profiles."
    },
    {
      id: "telemetry-dashboard",
      code: "TLM-03",
      title: "Telemetry & Performance Dashboard",
      description: "The central nervous system of the pit wall. Renders real-time graphs for speeds, engine RPM, throttle, and brake pressure.",
      metrics: [
        "Interactive line charts mapping RPM and Speed",
        "Sector 1, 2, and 3 timing deltas",
        "DRS zone activation status"
      ],
      tips: "Observe the throttle/brake overlays in real-time. Full green throttle indicates straight-line high-speed runs, while red spikes register heavy deceleration zones."
    },
    {
      id: "strategy-center",
      code: "STRAT-04",
      title: "Tire Strategy Center",
      description: "Monitors active tire compound wear indices, lap age, and simulates optimal pit-stop timing windows.",
      metrics: [
        "Remaining sector compound wear percentage",
        "Primary vs. alternative pit stop target laps",
        "Undercut advantage and overcut deltas"
      ],
      tips: "Click 'Run Tactical Simulation' to execute a Monte Carlo predictive model that tracks optimal lap targets based on active tire degradation levels."
    },
    {
      id: "prediction-engine",
      code: "PRED-05",
      title: "Race Prediction Engine",
      description: "Calculates win, podium, and top-5 finishing probabilities in real-time based on current telemetry streams.",
      metrics: [
        "Dynamic win / podium probability percentages",
        "Expected finishing positions projections",
        "Historical pace progression traces"
      ],
      tips: "Watch this panel react to tire age and flag changes. High tire wear or safety car intervals will dynamically recalculate the podium odds."
    },
    {
      id: "ai-engineer",
      code: "COMMS-06",
      title: "AI Race Engineer",
      description: "A direct cockpit-to-pitwall radio uplink powered by Gemini models for satellite telemetry analysis.",
      metrics: [
        "Real-time voice radio transcript transmission",
        "F1 engineer roleplay and tactical coaching",
        "Automatic local simulation failover mode"
      ],
      tips: "Use the quick-select buttons to ask about sector deficits or type custom questions regarding strategy and battery state."
    }
  ];

  const toggleItem = (id: string) => {
    setActiveItem(activeItem === id ? null : id);
  };

  return (
    <div 
      className="bg-black/85 backdrop-blur-xl rounded-xl p-5 border border-zinc-800/80 shadow-[0_4px_20px_rgba(0,0,0,0.5)] hover:border-red-500/10 transition-all flex flex-col"
      id="user-guide-panel"
    >
      {/* Header */}
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center justify-between w-full pb-3 border-b border-zinc-900/60 text-left focus:outline-none group"
        id="btn-toggle-guide"
      >
        <div className="flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-red-500 group-hover:rotate-6 transition-transform" />
          <div>
            <h2 className="text-xs font-black tracking-widest text-zinc-150 uppercase font-sans">
              Workstation Operational Manual
            </h2>
            <p className="text-[8px] text-zinc-500 font-mono uppercase font-bold tracking-wider mt-0.5">
              Engineer Onboarding & Component Guide
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[8px] font-mono font-black text-red-500 bg-red-950/40 px-1.5 py-0.5 rounded border border-red-900/40 tracking-wider">
            SYSTEM-DOCS
          </span>
          {isOpen ? <ChevronUp className="w-4 h-4 text-zinc-400" /> : <ChevronDown className="w-4 h-4 text-zinc-400" />}
        </div>
      </button>

      {/* Manual Content */}
      {isOpen ? (
        <div className="mt-4 space-y-3" id="guide-content-area">
          <p className="text-[10px] text-zinc-400 leading-relaxed font-sans border-b border-zinc-900/40 pb-2.5">
            Welcome, Systems Engineer. This telemetry workstation provides high-fidelity, real-time insights from the Oracle Satellite Uplink. Refer to the modules below to optimize team strategies and cockpit radio decisions.
          </p>

          <div className="space-y-2 max-h-[350px] overflow-y-auto pr-1 scrollbar-thin scrollbar-thumb-zinc-850">
            {guideItems.map((item) => {
              const isSelected = activeItem === item.id;
              return (
                <div 
                  key={item.id} 
                  className={`border rounded transition-all duration-200 ${
                    isSelected ? "bg-zinc-950/80 border-red-900/40" : "bg-zinc-950/20 border-zinc-900 hover:border-zinc-800"
                  }`}
                  id={`guide-item-${item.id}`}
                >
                  <button
                    onClick={() => toggleItem(item.id)}
                    className="w-full flex items-center justify-between p-2.5 text-left focus:outline-none"
                  >
                    <div className="flex items-center gap-2.5">
                      <span className="text-[8px] font-mono font-bold bg-zinc-900 text-zinc-400 px-1.5 py-0.5 rounded border border-zinc-800">
                        {item.code}
                      </span>
                      <span className="text-xs font-bold text-zinc-200 uppercase tracking-wide">
                        {item.title}
                      </span>
                    </div>
                    {isSelected ? <ChevronUp className="w-3.5 h-3.5 text-red-500" /> : <ChevronDown className="w-3.5 h-3.5 text-zinc-500" />}
                  </button>

                  {isSelected && (
                    <div className="px-2.5 pb-3 border-t border-zinc-900/60 pt-2.5 space-y-2">
                      <p className="text-[11px] text-zinc-400 leading-relaxed font-sans">
                        {item.description}
                      </p>

                      <div className="bg-black/60 p-2 rounded border border-zinc-900 space-y-1">
                        <span className="text-[8px] text-zinc-500 font-mono font-black uppercase tracking-wider block">Key Telemetry Metrics:</span>
                        <ul className="list-disc pl-3.5 text-[10px] text-zinc-400 space-y-0.5 font-sans">
                          {item.metrics.map((metric, i) => (
                            <li key={i}>{metric}</li>
                          ))}
                        </ul>
                      </div>

                      <div className="bg-red-950/10 p-2 rounded border border-red-950/20 flex gap-2">
                        <Info className="w-3.5 h-3.5 text-red-400 shrink-0 mt-0.5" />
                        <div className="text-[10px] text-red-300 leading-relaxed font-sans">
                          <span className="font-bold uppercase text-[9px] block text-red-400 font-mono">Paddock Tip:</span>
                          {item.tips}
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        <div 
          onClick={() => setIsOpen(true)}
          className="mt-3 bg-zinc-950/40 border border-zinc-900 rounded p-3 text-center cursor-pointer hover:bg-zinc-950/80 transition-all flex items-center justify-center gap-2"
          id="guide-collapsed-prompt"
        >
          <HelpCircle className="w-4 h-4 text-red-500 animate-pulse" />
          <span className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest font-mono">
            Expand Workstation Manual
          </span>
        </div>
      )}
    </div>
  );
}

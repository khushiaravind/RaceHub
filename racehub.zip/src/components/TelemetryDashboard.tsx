import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, CartesianGrid, Tooltip, AreaChart, Area } from "recharts";
import { TelemetryState, F1Team, F1Driver } from "../types";
import { Activity, Gauge, Disc, Zap, Flame, Compass, RefreshCw, BarChart2 } from "lucide-react";

interface TelemetryDashboardProps {
  telemetryState: TelemetryState;
  activeTeam: F1Team;
  activeDriver: F1Driver;
  historyData: any[]; // Stream of telemetry snapshots over time
  lapProgressionData: any[]; // Stream of lap history
}

export default function TelemetryDashboard({
  telemetryState,
  activeTeam,
  activeDriver,
  historyData,
  lapProgressionData,
}: TelemetryDashboardProps) {

  // Format historical speed data for charting
  const speedChartData = historyData.map((d, index) => ({
    tick: index,
    speed: d.speed,
    rpm: d.rpm / 40, // Scale RPM for comparison
  }));

  // Format historical pedal inputs
  const pedalChartData = historyData.map((d, index) => ({
    tick: index,
    throttle: d.throttle,
    brake: d.brake,
  }));

  // Format tire degradation prediction curve
  // A dynamic calculation showing how tires age over laps
  const tireAge = telemetryState.tireAge;
  const currentWear = telemetryState.tireWear;
  const tirePredictionData = Array.from({ length: 45 }).map((_, i) => {
    const projectedLap = i + 1;
    // Base compound wear coefficient
    const rate = telemetryState.tireCompound === "Soft" ? 2.5 : telemetryState.tireCompound === "Medium" ? 1.6 : 1.1;
    const projectedWear = Math.min(100, Math.round(projectedLap * rate));
    const projectedGrip = Math.max(0, 100 - projectedWear);
    return {
      lap: projectedLap,
      wear: projectedWear,
      grip: projectedGrip,
    };
  });

  return (
    <div className="space-y-6" id="telemetry-dashboard-container">
      {/* SECTION 1: LIVE METRICS CARDS GRID */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        {/* SPEED CARD */}
        <div className="bg-black/85 backdrop-blur-xl rounded-xl p-4 border border-zinc-800/80 relative overflow-hidden flex flex-col justify-between shadow-[0_4px_20px_rgba(0,0,0,0.5)] transition-all hover:border-red-500/30" id="metric-speed">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-zinc-500 font-extrabold uppercase tracking-widest font-mono">Live Speed</span>
            <Gauge className="w-3.5 h-3.5 text-red-500" />
          </div>
          <div className="my-2.5">
            <div className="flex items-baseline gap-1">
              <span className="text-4.5xl font-black font-mono text-zinc-100 tracking-tight glow-red">
                {telemetryState.speed}
              </span>
              <span className="text-[10px] text-zinc-450 uppercase font-black font-mono">KM/H</span>
            </div>
            {/* Visual speed progress slider */}
            <div className="w-full bg-zinc-900/90 h-1.5 rounded-full overflow-hidden mt-2 border border-zinc-800/50">
              <div 
                className="h-full transition-all duration-300 shadow-[0_0_8px_rgba(239,68,68,0.5)]"
                style={{ width: `${Math.min(100, (telemetryState.speed / 360) * 100)}%`, backgroundColor: activeTeam.baseColor }}
              />
            </div>
          </div>
          <div className="text-[9px] text-zinc-500 font-mono flex justify-between uppercase font-bold">
            <span>PEAK: <span className="text-zinc-300">349 KM/H</span></span>
            <span className="text-emerald-400">OPTIMAL</span>
          </div>
        </div>

        {/* RPM CARD */}
        <div className="bg-black/85 backdrop-blur-xl rounded-xl p-4 border border-zinc-800/80 relative overflow-hidden flex flex-col justify-between shadow-[0_4px_20px_rgba(0,0,0,0.5)] transition-all hover:border-zinc-700" id="metric-rpm">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-zinc-500 font-extrabold uppercase tracking-widest font-mono">Engine RPM</span>
            <Zap className="w-3.5 h-3.5 text-yellow-500" />
          </div>
          <div className="my-2.5">
            <div className="flex items-baseline gap-1">
              <span className="text-3xl font-black font-mono text-zinc-100 tracking-tight">
                {telemetryState.rpm.toLocaleString()}
              </span>
              <span className="text-[9px] text-zinc-500 uppercase font-black font-mono">RPM</span>
            </div>
            <div className="flex gap-0.5 mt-2.5 bg-zinc-950 p-1 rounded border border-zinc-900">
              {Array.from({ length: 15 }).map((_, i) => {
                const fraction = i / 15;
                const active = telemetryState.rpm > (8000 + fraction * 7000);
                let color = "bg-zinc-900/60";
                if (active) {
                  if (i < 8) color = "bg-emerald-500 shadow-[0_0_4px_rgba(16,185,129,0.4)]";
                  else if (i < 12) color = "bg-yellow-500 shadow-[0_0_4px_rgba(245,158,11,0.4)]";
                  else color = "bg-red-500 animate-pulse shadow-[0_0_6px_rgba(239,68,68,0.6)]";
                }
                return <div key={i} className={`h-2 flex-1 rounded-xs ${color} transition-all duration-150`} />;
              })}
            </div>
          </div>
          <div className="text-[9px] text-zinc-500 font-mono flex justify-between uppercase font-bold">
            <span>ICE SHIFT MAP 3</span>
            <span className="text-emerald-400">MGU-K SYNC</span>
          </div>
        </div>

        {/* THROTTLE / BRAKE CARD */}
        <div className="bg-black/85 backdrop-blur-xl rounded-xl p-4 border border-zinc-800/80 relative overflow-hidden flex flex-col justify-between shadow-[0_4px_20px_rgba(0,0,0,0.5)] transition-all hover:border-zinc-700" id="metric-pedals">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-zinc-500 font-extrabold uppercase tracking-widest font-mono">Pedals</span>
            <Flame className="w-3.5 h-3.5 text-orange-500" />
          </div>
          <div className="my-2 space-y-2">
            <div>
              <div className="flex justify-between text-[9px] text-zinc-450 font-mono mb-0.5 uppercase font-bold">
                <span>THR: <span className="text-emerald-400 font-black">{telemetryState.throttle}%</span></span>
                <span>BS: Opt</span>
              </div>
              <div className="w-full bg-zinc-950 h-1.5 rounded-full overflow-hidden border border-zinc-900">
                <div 
                  className="h-full bg-emerald-500 transition-all duration-150 shadow-[0_0_6px_rgba(16,185,129,0.4)]"
                  style={{ width: `${telemetryState.throttle}%` }}
                />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-[9px] text-zinc-450 font-mono mb-0.5 uppercase font-bold">
                <span>BRK: <span className="text-red-500 font-black">{telemetryState.brake}%</span></span>
                <span>TEMP: 624°C</span>
              </div>
              <div className="w-full bg-zinc-950 h-1.5 rounded-full overflow-hidden border border-zinc-900">
                <div 
                  className="h-full bg-red-500 transition-all duration-150 shadow-[0_0_6px_rgba(239,68,68,0.4)]"
                  style={{ width: `${telemetryState.brake}%` }}
                />
              </div>
            </div>
          </div>
          <div className="text-[9px] text-zinc-500 font-mono flex justify-between uppercase font-bold">
            <span>BIAS: <span className="text-zinc-300">54.5%</span></span>
            <span className="text-zinc-400">TELEMETRY LOCK</span>
          </div>
        </div>

        {/* GEAR & DRS STATUS */}
        <div className="bg-black/85 backdrop-blur-xl rounded-xl p-4 border border-zinc-800/80 relative overflow-hidden flex flex-col justify-between shadow-[0_4px_20px_rgba(0,0,0,0.5)] transition-all hover:border-zinc-700" id="metric-gears">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-zinc-500 font-extrabold uppercase tracking-widest font-mono">Gear & DRS</span>
            <span className="text-[10px] font-black font-mono text-zinc-500">RATIO: OPT</span>
          </div>
          <div className="my-2.5 flex items-center justify-between">
            <div className="text-5xl font-black font-mono text-zinc-50 leading-none tracking-tighter">
              {telemetryState.gear === 0 ? "N" : telemetryState.gear}
            </div>
            <div className="flex flex-col items-end gap-1">
              <span className="text-[8px] text-zinc-500 uppercase font-black tracking-widest font-mono">DRS Flag</span>
              <span className={`text-[9px] px-2 py-1 rounded font-mono font-extrabold uppercase tracking-wider border transition-all ${
                telemetryState.drs 
                  ? "bg-emerald-950/60 text-emerald-400 border-emerald-500/40 animate-pulse shadow-[0_0_10px_rgba(16,185,129,0.25)]" 
                  : "bg-zinc-950 text-zinc-600 border-zinc-900"
              }`}>
                {telemetryState.drs ? "DRS OPEN" : "DRS CLOSED"}
              </span>
            </div>
          </div>
          <div className="text-[9px] text-zinc-500 font-mono flex justify-between uppercase font-bold">
            <span>SLIP: <span className="text-zinc-300">0.14%</span></span>
            <span className="text-zinc-400">KINETIC LOCK</span>
          </div>
        </div>

        {/* TYRE LIFE & LOAD */}
        <div className="bg-black/85 backdrop-blur-xl rounded-xl p-4 border border-zinc-800/80 relative overflow-hidden flex flex-col justify-between shadow-[0_4px_20px_rgba(0,0,0,0.5)] transition-all hover:border-zinc-700" id="metric-tires">
          <div className="flex items-center justify-between">
            <span className="text-[10px] text-zinc-500 font-extrabold uppercase tracking-widest font-mono">Tyre Status</span>
            <Disc className="w-3.5 h-3.5 text-zinc-500" />
          </div>
          <div className="my-2 flex items-center justify-between gap-1">
            <div className="flex flex-col">
              <div className="flex items-center gap-2">
                {/* Real Pirelli-inspired tyre compound ring badge */}
                <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center font-black text-[10px] select-none ${
                  telemetryState.tireCompound === "Soft" ? "border-red-650 bg-black text-red-500 shadow-[0_0_8px_rgba(239,68,68,0.3)]" :
                  telemetryState.tireCompound === "Medium" ? "border-yellow-500 bg-black text-yellow-500 shadow-[0_0_8px_rgba(245,158,11,0.3)]" :
                  telemetryState.tireCompound === "Hard" ? "border-white bg-black text-white shadow-[0_0_8px_rgba(255,255,255,0.25)]" :
                  "border-blue-500 bg-black text-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.3)]"
                }`}>
                  {telemetryState.tireCompound[0]}
                </div>
                <span className="text-xs font-black text-zinc-150 font-mono tracking-wide uppercase">{telemetryState.tireCompound}</span>
              </div>
              <span className="text-[9px] text-zinc-500 font-mono mt-1.5 font-bold uppercase">{telemetryState.tireAge} LAPS OLD</span>
            </div>

            {/* Tire heat/wear progress bar */}
            <div className="flex flex-col items-end">
              <span className="text-xs font-mono font-black text-zinc-200">WEAR: {Math.round(telemetryState.tireWear)}%</span>
              <span className={`text-[8px] tracking-wider uppercase font-black mt-1 px-1.5 py-0.5 rounded border ${
                telemetryState.tireWear > 50 
                  ? "bg-red-950/60 text-red-400 border-red-900/40 animate-pulse" 
                  : "bg-emerald-950/60 text-emerald-400 border-emerald-900/40"
              }`}>
                {telemetryState.tireWear > 50 ? "CRITICAL" : "OPTIMAL"}
              </span>
            </div>
          </div>
          <div className="text-[9px] text-zinc-500 font-mono flex justify-between uppercase font-bold">
            <span>PRES: <span className="text-zinc-300">22.4 PSI</span></span>
            <span>CORE: <span className="text-zinc-300">104°C</span></span>
          </div>
        </div>
      </div>

      {/* SECTION 2: GRAPHICAL TELEMETRY TRACES */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* SPEED & ENGINE RPM REAL-TIME CHART (7 Columns) */}
        <div className="col-span-1 lg:col-span-7 bg-black/85 backdrop-blur-xl rounded-xl p-5 border border-zinc-800/80 shadow-[0_4px_20px_rgba(0,0,0,0.5)] hover:border-red-500/20 transition-all" id="panel-speed-trace">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center gap-2">
              <Activity className="w-4.5 h-4.5 text-red-500" />
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">Continuous Speed Trace</h3>
                <p className="text-[9px] text-zinc-500 font-mono uppercase">Streaming telemetry telemetry log points (60 FPS interpolation)</p>
              </div>
            </div>
            <div className="flex gap-4 text-[10px] font-mono">
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-1 rounded text-red-500 inline-block bg-red-500"></span>Speed (km/h)</span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-1 inline-block" style={{ backgroundColor: activeTeam.baseColor }} />
                Scaled RPM
              </span>
            </div>
          </div>

          <div className="h-[210px] w-full bg-black/30 border border-zinc-900 rounded-lg p-2 overflow-hidden">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={speedChartData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#18181b" />
                <XAxis dataKey="tick" stroke="#71717a" fontSize={9} fontStyle="italic" />
                <YAxis stroke="#71717a" domain={[0, 400]} fontSize={9} />
                <Tooltip 
                  contentStyle={{ backgroundColor: "#09090b", borderColor: "#27272a", borderRadius: 8 }}
                  labelStyle={{ color: "#a1a1aa", fontSize: 10 }}
                  itemStyle={{ fontSize: 11 }}
                />
                <Line 
                  type="monotone" 
                  dataKey="speed" 
                  stroke="#E10600" 
                  strokeWidth={2.5} 
                  dot={false}
                  activeDot={{ r: 4 }}
                  isAnimationActive={false}
                />
                <Line 
                  type="monotone" 
                  dataKey="rpm" 
                  stroke={activeTeam.baseColor} 
                  strokeWidth={1.5} 
                  dot={false}
                  isAnimationActive={false}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* PEDAL INPUT TRACE (5 Columns) */}
        <div className="col-span-1 lg:col-span-5 bg-black/85 backdrop-blur-xl rounded-xl p-5 border border-zinc-800/80 shadow-[0_4px_20px_rgba(0,0,0,0.5)] hover:border-zinc-700 transition-all" id="panel-pedals-trace">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center gap-2">
              <BarChart2 className="w-4.5 h-4.5 text-zinc-400" />
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">Throttle & Brake Deltas</h3>
                <p className="text-[9px] text-zinc-500 font-mono uppercase">Inter-sector pedal pressure inputs</p>
              </div>
            </div>
            <div className="flex gap-3 text-[10px] font-mono font-bold">
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-1 bg-emerald-500 rounded-sm"></span>THR</span>
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-1 bg-red-500 rounded-sm"></span>BRK</span>
            </div>
          </div>

          <div className="h-[210px] w-full bg-black/30 border border-zinc-900 rounded-lg p-2 overflow-hidden">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={pedalChartData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#18181b" />
                <XAxis dataKey="tick" stroke="#71717a" fontSize={9} />
                <YAxis stroke="#71717a" domain={[0, 100]} fontSize={9} />
                <Tooltip 
                  contentStyle={{ backgroundColor: "#09090b", borderColor: "#27272a", borderRadius: 8 }}
                  itemStyle={{ fontSize: 11 }}
                />
                <Line type="monotone" dataKey="throttle" stroke="#10B981" strokeWidth={2} dot={false} isAnimationActive={false} />
                <Line type="monotone" dataKey="brake" stroke="#EF4444" strokeWidth={2} dot={false} isAnimationActive={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* SECTION 3: DEGRADATION MAP & LAP PROGRESS */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* TIRE DEGRADATION PREDICTION */}
        <div className="bg-black/85 backdrop-blur-xl rounded-xl p-5 border border-zinc-800/80 shadow-[0_4px_20px_rgba(0,0,0,0.5)] hover:border-zinc-700 transition-all" id="panel-degradation">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <Disc className="w-4.5 h-4.5 text-yellow-500 animate-spin" style={{ animationDuration: '8s' }} />
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">Tyre Grip & Degradation Curves</h3>
                <p className="text-[9px] text-zinc-500 font-mono uppercase">Compound simulation over 45 laps based on active {telemetryState.tireCompound}</p>
              </div>
            </div>
            <span className="text-[10px] font-mono text-emerald-400 bg-emerald-950/40 px-2.5 py-0.5 rounded border border-emerald-900/30 uppercase font-bold">
              CROSSOVER LAP 28
            </span>
          </div>

          <div className="h-[180px] w-full bg-black/30 border border-zinc-900 rounded-lg p-2 overflow-hidden">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={tirePredictionData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#18181b" />
                <XAxis dataKey="lap" stroke="#71717a" fontSize={9} />
                <YAxis stroke="#71717a" fontSize={9} />
                <Tooltip contentStyle={{ backgroundColor: "#09090b", borderColor: "#27272a" }} />
                <Area type="monotone" dataKey="grip" stackId="1" stroke="#3B82F6" fill="#1e3a8a" fillOpacity={0.25} name="Calculated Grip %" />
                <Area type="monotone" dataKey="wear" stackId="2" stroke="#EF4444" fill="#7f1d1d" fillOpacity={0.15} name="Degradation %" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* LAP TIME PROGRESSION BAR CHART */}
        <div className="bg-black/85 backdrop-blur-xl rounded-xl p-5 border border-zinc-800/80 shadow-[0_4px_20px_rgba(0,0,0,0.5)] hover:border-zinc-700 transition-all" id="panel-lap-progression">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <BarChart2 className="w-4.5 h-4.5 text-orange-500" />
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-200">Lap Time Delta Chart</h3>
                <p className="text-[9px] text-zinc-500 font-mono uppercase">Difference in pace (seconds) against team baseline</p>
              </div>
            </div>
            <span className="text-[10px] text-zinc-400 font-mono font-bold bg-zinc-950 px-2 py-0.5 rounded border border-zinc-900">
              AVG: +0.221s
            </span>
          </div>

          <div className="h-[180px] w-full bg-black/30 border border-zinc-900 rounded-lg p-2 overflow-hidden">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={lapProgressionData} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#18181b" />
                <XAxis dataKey="lap" stroke="#71717a" fontSize={9} />
                <YAxis stroke="#71717a" fontSize={9} />
                <Tooltip contentStyle={{ backgroundColor: "#09090b", borderColor: "#27272a" }} />
                <Area type="monotone" dataKey="delta" stroke="#F59E0B" fill="#f59e0b" fillOpacity={0.15} name="Lap Delta (s)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}

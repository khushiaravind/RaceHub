import { useState } from "react";
import { F1Driver, F1Team, DRIVERS, TEAMS } from "../types";
import { Users, User, ArrowRight, Award, Trophy, Bookmark, Zap } from "lucide-react";

interface DriverCenterProps {
  favoriteDriver: F1Driver;
  comparisonDriver: F1Driver;
  favoriteTeam: F1Team;
  isCompareMode: boolean;
  onSelectFavoriteDriver: (driver: F1Driver) => void;
  onSelectComparisonDriver: (driver: F1Driver) => void;
  onSelectFavoriteTeam: (team: F1Team) => void;
  onToggleCompareMode: (isActive: boolean) => void;
}

export default function DriverCenter({
  favoriteDriver,
  comparisonDriver,
  favoriteTeam,
  isCompareMode,
  onSelectFavoriteDriver,
  onSelectComparisonDriver,
  onSelectFavoriteTeam,
  onToggleCompareMode
}: DriverCenterProps) {
  const [activeTab, setActiveTab] = useState<"card" | "compare">("card");

  // Handle dropdown selects
  const handleFavDriverChange = (driverId: string) => {
    const driver = DRIVERS.find((d) => d.id === driverId);
    if (driver) {
      onSelectFavoriteDriver(driver);
      // Auto update team if driver's actual team is in our TEAMS list
      if (TEAMS[driver.team]) {
        onSelectFavoriteTeam(TEAMS[driver.team]);
      }
    }
  };

  const handleCompDriverChange = (driverId: string) => {
    const driver = DRIVERS.find((d) => d.id === driverId);
    if (driver) {
      onSelectComparisonDriver(driver);
    }
  };

  const handleTeamChange = (teamName: string) => {
    const team = TEAMS[teamName];
    if (team) {
      onSelectFavoriteTeam(team);
    }
  };

  // Compare telemetry metrics
  const comparisonMetrics = [
    { name: "Top Speed (DRS)", p1: 348, p2: 341, unit: "km/h", tag: "speed" },
    { name: "Apex Throttle Apex %", p1: 96, p2: 91, unit: "%", tag: "throttle" },
    { name: "Average Brake Pressure", p1: 45, p2: 48, unit: "bar", tag: "brake" },
    { name: "Tire Longevity Wear Rate", p1: 1.4, p2: 1.7, unit: "% / Lap", tag: "tire" },
    { name: "Qualifying Pace Mean Delta", p1: -0.05, p2: 0.12, unit: "s", tag: "pace", invert: true },
    { name: "Sector 1 Apex Split", p1: 27.84, p2: 28.02, unit: "s", tag: "s1", invert: true },
    { name: "Sector 2 Apex Split", p1: 33.15, p2: 33.42, unit: "s", tag: "s2", invert: true },
    { name: "Sector 3 Apex Split", p1: 20.89, p2: 21.11, unit: "s", tag: "s3", invert: true },
  ];

  return (
    <div className="bg-black/85 backdrop-blur-xl rounded-xl p-5 border border-zinc-800/80 flex flex-col h-full shadow-[0_4px_20px_rgba(0,0,0,0.5)] hover:border-red-500/10 transition-all" id="driver-center-container">
      {/* Header Selector Bar */}
      <div className="flex flex-col gap-3 md:flex-row md:items-center justify-between pb-4 border-b border-zinc-900/60">
        <div className="flex items-center gap-2">
          <Users className="w-4 h-4 text-red-500 animate-pulse" />
          <h2 className="text-xs font-black tracking-widest text-zinc-150 uppercase font-sans">
            Driver Hub & Comparison
          </h2>
        </div>

        {/* View Mode Custom Switches */}
        <div className="flex items-center gap-1 bg-zinc-950 p-1 rounded-md border border-zinc-900">
          <button
            onClick={() => {
              setActiveTab("card");
              onToggleCompareMode(false);
            }}
            className={`px-3 py-1 text-[10px] uppercase tracking-wider rounded transition-all duration-150 ${
              !isCompareMode && activeTab === "card"
                ? "bg-zinc-800 text-slate-100 font-bold border border-zinc-700/80"
                : "text-zinc-500 hover:text-zinc-350"
            }`}
            id="toggle-driver-card"
          >
            Driver Profile
          </button>
          <button
            onClick={() => {
              setActiveTab("compare");
              onToggleCompareMode(true);
            }}
            className={`px-3 py-1 text-[10px] uppercase tracking-wider rounded transition-all duration-150 flex items-center gap-1 ${
              isCompareMode
                ? "bg-red-600 text-white font-bold shadow-md shadow-red-950/20"
                : "text-zinc-500 hover:text-zinc-350"
            }`}
            id="btn-compare-drivers"
          >
            <Zap className="w-2.5 h-2.5" />
            Compare Mode
          </button>
        </div>
      </div>

      {/* Selectors Matrix */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 my-4">
        {/* Favorite Driver Selection */}
        <div className="flex flex-col gap-1">
          <label className="text-[9px] text-zinc-500 font-extrabold tracking-widest uppercase font-mono">Focus Driver</label>
          <select
            value={favoriteDriver.id}
            onChange={(e) => handleFavDriverChange(e.target.value)}
            className="w-full bg-zinc-950 border border-zinc-850 text-slate-200 text-xs rounded px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-red-500 font-medium"
            id="fav-driver-select"
          >
            {DRIVERS.map((d) => (
              <option key={d.id} value={d.id}>
                {d.name} ({d.code})
              </option>
            ))}
          </select>
        </div>

        {/* Favorite Team Selection */}
        <div className="flex flex-col gap-1">
          <label className="text-[9px] text-zinc-500 font-extrabold tracking-widest uppercase font-mono">Active Team Pitwall</label>
          <select
            value={favoriteTeam.name}
            onChange={(e) => handleTeamChange(e.target.value)}
            className="w-full bg-zinc-950 border border-zinc-850 text-slate-200 text-xs rounded px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-red-500"
            id="favorite-team-select"
          >
            {Object.keys(TEAMS).map((tName) => (
              <option key={tName} value={tName}>
                {tName}
              </option>
            ))}
          </select>
        </div>

        {/* Comparison Driver Selection */}
        <div className="flex flex-col gap-1">
          <label className="text-[9px] text-zinc-500 font-extrabold tracking-widest uppercase font-mono">Rival/Compare Driver</label>
          <select
            value={comparisonDriver.id}
            onChange={(e) => handleCompDriverChange(e.target.value)}
            className="w-full bg-zinc-950 border border-zinc-850 text-slate-200 text-xs rounded px-2.5 py-1.5 focus:outline-none focus:ring-1 focus:ring-blue-500 font-medium"
            id="compare-driver-select"
          >
            {DRIVERS.filter((d) => d.id !== favoriteDriver.id).map((d) => (
              <option key={d.id} value={d.id}>
                {d.name} ({d.code})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Visual Content Panels */}
      {!isCompareMode ? (
        /* PREMIUM ANIMATED PROFILE CARD (FOR FOCUS DRIVER) */
        <div 
          className="flex-1 relative rounded-xl border border-zinc-800 overflow-hidden flex flex-col p-5 transition-all duration-300 shadow-xl group bg-black/60"
          id="driver-profile-card-display"
        >
          {/* Glowing back lighting according to team */}
          <div 
            className="absolute -right-12 -top-12 w-48 h-48 rounded-full blur-[60px] opacity-20 group-hover:opacity-35 transition-all duration-300"
            style={{ backgroundColor: favoriteTeam.baseColor }}
          />
          <div 
            className="absolute -left-12 -bottom-12 w-32 h-32 rounded-full blur-[40px] opacity-10"
            style={{ backgroundColor: favoriteTeam.secondaryColor }}
          />

          {/* Motorsport style visual details */}
          <div className="absolute right-4 bottom-4 text-7xl font-mono opacity-[0.05] font-black select-none text-right">
            #{favoriteDriver.number}
            <div className="text-[8px] tracking-[4px] uppercase fill-zinc-300">TELEMETRY LOCK</div>
          </div>

          <div className="flex items-start justify-between z-10">
            {/* Driver Name & Number Block */}
            <div className="flex flex-col">
              <span className="text-[9px] font-bold text-zinc-500 uppercase tracking-widest font-mono">
                Focus Driver Profile
              </span>
              <h3 className="text-lg font-black text-slate-100 tracking-tight mt-1 inline-flex items-center gap-2">
                {favoriteDriver.name}
                <span 
                  className="px-2 py-0.5 rounded text-[10px] font-mono font-black"
                  style={{ backgroundColor: `${favoriteTeam.baseColor}33`, color: favoriteTeam.secondaryColor, border: `1px solid ${favoriteTeam.baseColor}44` }}
                >
                  #{favoriteDriver.number}
                </span>
              </h3>
              <p className="text-xs text-zinc-400 font-sans mt-0.5 inline-flex items-center gap-1.5">
                <span className="inline-block w-2.5 h-1.5 rounded-xs" style={{ backgroundColor: favoriteTeam.baseColor }}></span> {favoriteDriver.nationality} • {favoriteDriver.team}
              </p>
            </div>

            {/* Championship Position Badge */}
            <div className="flex flex-col items-center bg-zinc-950 border border-zinc-850 p-2 rounded font-mono min-w-[65px] text-center shadow-inner">
              <span className="text-[8px] text-zinc-500 uppercase tracking-widest font-bold">P-RANK</span>
              <span className="text-base font-extrabold text-red-500">P{favoriteDriver.championshipPosition}</span>
              <span className="text-[8px] text-zinc-450 mt-0.5 font-bold">{favoriteDriver.points} PTS</span>
            </div>
          </div>

          {/* F1 Stats Grid */}
          <div className="grid grid-cols-5 gap-2.5 mt-4.5 z-10 flex-1">
            <div className="bg-zinc-950/70 border border-zinc-900 p-2 rounded flex flex-col items-center justify-center text-center shadow-sm">
              <Trophy className="w-3.5 h-3.5 text-yellow-500 mb-1" />
              <span className="text-sm font-black text-slate-200 font-mono">{favoriteDriver.wins}</span>
              <span className="text-[8px] text-zinc-500 uppercase tracking-wider mt-0.5 font-bold">Wins</span>
            </div>
            <div className="bg-zinc-950/70 border border-zinc-900 p-2 rounded flex flex-col items-center justify-center text-center shadow-sm">
              <Award className="w-3.5 h-3.5 text-emerald-500 mb-1" />
              <span className="text-sm font-black text-slate-200 font-mono">{favoriteDriver.podiums}</span>
              <span className="text-[8px] text-zinc-500 uppercase tracking-wider mt-0.5 font-bold">Podiums</span>
            </div>
            <div className="bg-zinc-950/70 border border-zinc-900 p-2 rounded flex flex-col items-center justify-center text-center shadow-sm">
              <Bookmark className="w-3.5 h-3.5 text-blue-400 mb-1" />
              <span className="text-sm font-black text-slate-200 font-mono">{favoriteDriver.polePositions}</span>
              <span className="text-[8px] text-zinc-500 uppercase tracking-wider mt-0.5 font-bold">Poles</span>
            </div>
            <div className="bg-zinc-950/70 border border-zinc-900 p-2 rounded flex flex-col items-center justify-center text-center shadow-sm">
              <Zap className="w-3.5 h-3.5 text-orange-400 mb-1 animate-pulse" />
              <span className="text-sm font-black text-slate-200 font-mono">{favoriteDriver.fastestLaps}</span>
              <span className="text-[8px] text-zinc-500 uppercase tracking-wider mt-0.5 font-bold">FLaps</span>
            </div>
            {/* Quick telemetry note */}
            <div className="col-span-1 bg-zinc-950/90 border border-red-950/40 rounded p-2 flex flex-col items-center justify-center text-center">
              <span className="text-zinc-600 text-[7px] tracking-wider uppercase block font-mono font-bold">PIT-WALL</span>
              <span className="text-red-500 font-black font-mono text-[10px] animate-pulse">LIVE</span>
              <span className="text-zinc-550 text-[7px] mt-0.5 truncate font-bold">SYNC</span>
            </div>
          </div>

          <div className="mt-4 bg-zinc-950/80 border border-zinc-900 rounded p-3 z-10 flex items-center justify-between text-[10px] text-zinc-400 shadow-inner">
            <span className="inline-flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              Satellite analysis sync: Active on Red Bull Telemetry Core
            </span>
            <span className="font-mono text-zinc-500 font-bold uppercase tracking-wide">PIT-GRID</span>
          </div>
        </div>
      ) : (
        /* DRIVER COMPARISON MODE SIDE-BY-SIDE PANEL */
        <div className="flex-1 bg-black/60 border border-zinc-900 rounded-xl p-4 flex flex-col overflow-y-auto max-h-[360px]" id="comparison-dashboard">
          <div className="flex justify-between items-center mb-3 text-[10px] uppercase tracking-wider font-bold">
            <span className="text-zinc-400">TELEMETRY LAP-COMPARE DELTA</span>
            <span className="text-zinc-500">Delta = Gain (Green) / Loss (Red)</span>
          </div>

          {/* Quick Header */}
          <div className="grid grid-cols-12 gap-1 pb-2 border-b border-zinc-900 text-[10px] uppercase font-mono text-zinc-400 font-bold">
            <div className="col-span-5 text-left flex items-center gap-1">
              <span className="inline-block w-2 h-2 bg-red-600 rounded-sm"></span> {favoriteDriver.code} (P{favoriteDriver.championshipPosition})
            </div>
            <div className="col-span-2 text-center text-zinc-500">Telemetry Metric</div>
            <div className="col-span-5 text-right flex items-center justify-end gap-1">
              {comparisonDriver.code} (P{comparisonDriver.championshipPosition}) <span className="inline-block w-2 h-2 bg-blue-600 rounded-sm"></span>
            </div>
          </div>

          {/* Comparison Rows */}
          <div className="space-y-3 mt-3 flex-1">
            {comparisonMetrics.map((metric, i) => {
              // Calculate delta. Negative is faster if invert is true (e.g. lap times)
              const d1 = metric.p1;
              const d2 = metric.p2;

              let isFirstBetter = d1 > d2;
              if (metric.invert) {
                isFirstBetter = d1 < d2;
              }

              const diffVal = Math.abs(d1 - d2);
              const formattedDiff = diffVal === 0 ? "EVEN" : `${isFirstBetter ? "-" : "+"}${diffVal.toFixed(2)}${metric.unit}`;

              // Visual bar variables
              const totalSum = d1 + d2;
              const percent1 = totalSum > 0 ? (d1 / totalSum) * 100 : 50;
              const percent2 = totalSum > 0 ? (d2 / totalSum) * 100 : 50;

              return (
                <div key={i} className="bg-zinc-950/70 border border-zinc-900/60 p-2.5 rounded flex flex-col hover:bg-zinc-950 transition-all duration-150">
                  <div className="flex justify-between items-center text-xs mb-1.5 font-sans">
                    {/* Driver 1 Value */}
                    <span className={`font-mono font-bold ${isFirstBetter ? "text-emerald-400" : "text-zinc-400"}`}>
                      {metric.p1}{metric.unit}
                    </span>

                    {/* Metric Name & Delta Bubble */}
                    <div className="text-center flex flex-col items-center">
                      <span className="text-[10px] text-zinc-400 font-medium tracking-wide">{metric.name}</span>
                      <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded mt-0.5 ${
                        diffVal === 0 ? "bg-zinc-800 text-zinc-400" :
                        isFirstBetter ? "bg-emerald-950/60 border border-emerald-900/40 text-emerald-400" : "bg-red-950/60 border border-red-955/50 text-red-500"
                      }`}>
                        {formattedDiff}
                      </span>
                    </div>

                    {/* Driver 2 Value */}
                    <span className={`font-mono font-bold ${!isFirstBetter ? "text-emerald-400" : "text-zinc-400"}`}>
                      {metric.p2}{metric.unit}
                    </span>
                  </div>

                  {/* Dual Percent Bar */}
                  <div className="h-1.5 w-full bg-zinc-950 rounded-full overflow-hidden flex border border-zinc-900">
                    <div 
                      className={`h-full transition-all duration-500 ${isFirstBetter ? "bg-emerald-500" : "bg-red-500/70"}`}
                      style={{ width: `${percent1}%` }}
                    />
                    <div 
                      className={`h-full transition-all duration-500 ${!isFirstBetter ? "bg-emerald-500" : "bg-red-500/70"}`}
                      style={{ width: `${percent2}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          {/* Visual confirmation of the faster driver */}
          <div className="mt-4 bg-zinc-950 border border-zinc-900 rounded p-3 flex items-center justify-between z-10 text-[11px] shadow-inner">
            <span className="font-extrabold text-zinc-400">APEX TARGET STATUS:</span>
            <span className="text-emerald-400 font-extrabold bg-emerald-950/80 px-2.5 py-1 rounded border border-emerald-800/40 uppercase tracking-wide">
              {favoriteDriver.code} FASTEST BY -0.170S
            </span>
          </div>
        </div>
      )}
    </div>
  );
}

import { Zap } from "lucide-react";

export default function RacehubLogo() {
  return (
    <div className="flex items-center gap-3 select-none" id="racehub-brand-logo">
      {/* Aerodynamic Speed Vector Shield */}
      <div className="relative flex items-center justify-center w-8 h-8 filter drop-shadow-[0_0_12px_rgba(239,68,68,0.45)] shrink-0">
        <svg className="w-full h-full" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Dynamic Red Chevrons */}
          <path d="M5 25 L85 10 L65 50 L95 90 L15 75 L35 50 Z" fill="#E10600" />
          {/* High-Contrast Inverted Center Grid */}
          <path d="M25 35 L70 25 L55 50 L75 75 L30 65 L45 50 Z" fill="#000000" />
          {/* Inner Light Speedline Accent */}
          <path d="M40 38 L58 48 L46 52 L54 62 L36 50 Z" fill="#FFFFFF" />
        </svg>
        <Zap className="absolute w-3 h-3 text-white fill-white animate-pulse" style={{ top: "45%", left: "44%", transform: "translate(-50%, -50%)" }} />
      </div>
      
      {/* Brand Typography */}
      <div className="flex flex-col">
        <div className="flex items-baseline leading-none">
          <span className="text-sm font-black tracking-tighter italic text-zinc-50 uppercase font-sans">
            RACE
          </span>
          <span className="text-sm font-black tracking-tighter italic text-red-600 uppercase font-sans pr-1">
            HUB
          </span>
          {/* Core Telemetry Tag */}
          <span className="text-[7px] font-mono font-black text-red-500 bg-red-950/80 px-1 py-0.5 rounded border border-red-900/40 tracking-wider ml-1">
            GP.4
          </span>
        </div>
        <span className="text-[7px] font-mono font-black text-zinc-500 uppercase tracking-[0.25em] mt-0.5 leading-none">
          TELEMETRY PORTAL
        </span>
      </div>
    </div>
  );
}

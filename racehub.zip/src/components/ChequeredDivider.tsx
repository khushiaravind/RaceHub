interface ChequeredDividerProps {
  className?: string;
  heightClass?: string;
}

export default function ChequeredDivider({ 
  className = "", 
  heightClass = "h-1.5" 
}: ChequeredDividerProps) {
  return (
    <div 
      className={`w-full flex ${heightClass} overflow-hidden opacity-90 border-t border-b border-black select-none ${className}`} 
      id="chequered-divider-strip"
    >
      {/* Generate 80 alternating squares */}
      {Array.from({ length: 80 }).map((_, i) => (
        <div 
          key={i} 
          className={`flex-1 h-full ${
            i % 2 === 0 
              ? "bg-zinc-100" 
              : "bg-zinc-950"
          }`} 
        />
      ))}
    </div>
  );
}

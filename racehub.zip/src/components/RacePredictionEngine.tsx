import { PredictionsData, F1Team, F1Driver } from "../types";
import { Award, Percent, TrendingUp, HelpCircle } from "lucide-react";

interface RacePredictionEngineProps {
  predictionData: PredictionsData;
  activeTeam: F1Team;
  activeDriver: F1Driver;
}

export default function RacePredictionEngine({
  predictionData,
  activeTeam,
  activeDriver,
}: RacePredictionEngineProps) {
  
  // Custom circular ring calculator
  const renderProgressRing = (percentage: number, color: string, glowColor: string, size = 90, strokeWidth = 8) => {
    const radius = (size - strokeWidth) / 2;
    const circumference = radius * 2 * Math.PI;
    const strokeDashoffset = circumference - (percentage / 100) * circumference;

    return (
      <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="transform -rotate-90">
          {/* Track ring */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke="#27272a"
            strokeWidth={strokeWidth}
            fill="transparent"
          />
          {/* Colored progress ring */}
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke={color}
            strokeWidth={strokeWidth}
            fill="transparent"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            className="transition-all duration-700 ease-out"
            style={{
              filter: `drop-shadow(0 0 6px ${glowColor}66)`
            }}
          />
        </svg>
        <div className="absolute flex flex-col items-center justify-center">
          <span className="text-sm font-black font-mono text-slate-100">{percentage}%</span>
        </div>
      </div>
    );
  };

  return (
    <div className="bg-black/85 backdrop-blur-xl rounded-xl p-5 border border-zinc-800/80 flex flex-col h-full shadow-[0_4px_20px_rgba(0,0,0,0.5)] hover:border-red-500/10 transition-all" id="prediction-engine-container">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-zinc-900/60 mb-4">
        <div className="flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-red-500 animate-pulse" />
          <h2 className="text-xs font-black tracking-widest text-zinc-150 uppercase font-sans">
            AI Prediction Engine
          </h2>
        </div>
        <span className="text-[8px] font-mono text-zinc-500 uppercase font-bold tracking-wider">Live Model v41r.2</span>
      </div>

      {/* Hero Prediction: Expected Finishing Position */}
      <div className="bg-zinc-950/60 border border-zinc-900 rounded-xl p-4 flex items-center justify-between mb-4 relative overflow-hidden shadow-inner">
        {/* Glow behind */}
        <div 
          className="absolute right-0 bottom-0 w-24 h-24 rounded-full blur-2xl opacity-10 pointer-events-none"
          style={{ backgroundColor: activeTeam.baseColor }}
        />
        <div className="flex flex-col">
          <span className="text-[9px] text-zinc-500 uppercase font-extrabold tracking-widest font-mono">Projected Position</span>
          <span className="text-[10px] text-zinc-450 mt-0.5 font-medium">Based on simulated race pace deltas</span>
          <p className="text-xs text-zinc-350 mt-2 font-medium">
            Active Driver: <span className="text-white font-mono font-black">{activeDriver.code}</span>
          </p>
        </div>

        <div className="bg-zinc-950 border border-zinc-900 p-3.5 rounded text-center font-mono min-w-[90px] border-l-4" style={{ borderLeftColor: activeTeam.baseColor }}>
          <span className="text-[8px] text-zinc-500 uppercase block font-black leading-none tracking-wider">EXPECTED</span>
          <span className="text-2.5xl font-black text-white mt-1 block tracking-tighter">P{predictionData.expectedFinish}</span>
          <span className="text-[8px] text-emerald-400 font-black block mt-1 uppercase tracking-widest">▲ {activeDriver.championshipPosition > predictionData.expectedFinish ? "Gain" : "Stable"}</span>
        </div>
      </div>

      {/* Circle Gauges Row */}
      <div className="grid grid-cols-3 gap-3 flex-1 items-center">
        {/* Win Probability Ring */}
        <div className="bg-zinc-950/40 p-3 rounded border border-zinc-900 flex flex-col items-center text-center shadow-sm">
          <span className="text-[8px] text-zinc-500 uppercase font-extrabold tracking-widest mb-2 font-mono">Win Chance</span>
          {renderProgressRing(predictionData.winProb, "#EF4444", "#EF4444", 80, 6)}
          <span className="text-[8px] text-zinc-500 font-mono uppercase tracking-wider font-bold mt-2.5">Highly Fluid</span>
        </div>

        {/* Podium Probability Ring */}
        <div className="bg-zinc-950/40 p-3 rounded border border-zinc-900 flex flex-col items-center text-center shadow-sm">
          <span className="text-[8px] text-zinc-500 uppercase font-extrabold tracking-widest mb-2 font-mono">Podium Prob</span>
          {renderProgressRing(predictionData.podiumProb, "#F59E0B", "#F59E0B", 80, 6)}
          <span className="text-[8px] text-zinc-500 font-mono uppercase tracking-wider font-bold mt-2.5">Optimal Pace</span>
        </div>

        {/* Top 5 Probability Ring */}
        <div className="bg-zinc-950/40 p-3 rounded border border-zinc-900 flex flex-col items-center text-center shadow-sm">
          <span className="text-[8px] text-zinc-500 uppercase font-extrabold tracking-widest mb-2 font-mono">Top 5 Finish</span>
          {renderProgressRing(predictionData.top5Prob, "#10B981", "#10B981", 80, 6)}
          <span className="text-[8px] text-zinc-500 font-mono uppercase tracking-wider font-bold mt-2.5">High Conf</span>
        </div>
      </div>

      {/* Strategic Note */}
      <div className="mt-4 bg-zinc-950/60 border border-zinc-900 rounded p-3 text-[10px] leading-relaxed text-zinc-400 flex items-start gap-2 shadow-inner">
        <HelpCircle className="w-3.5 h-3.5 text-zinc-600 shrink-0 mt-0.5 animate-pulse" />
        <p className="font-medium">
          Calculated by averaging multi-lap traction telemetry, competitor tire conditions, and live fuel mass estimates. Updates dynamically every racing sector.
        </p>
      </div>
    </div>
  );
}

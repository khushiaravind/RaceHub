import { useState, useRef, useEffect } from "react";
import { F1Driver, F1Team, ChatMessage, TelemetryState } from "../types";
import { Send, Terminal, ShieldAlert, Cpu, CornerDownLeft, Sparkles, Volume2, Radio } from "lucide-react";

interface AIEngineerPanelProps {
  favoriteDriver: F1Driver;
  favoriteTeam: F1Team;
  sessionType: string;
  telemetryState: TelemetryState;
  chatHistory: ChatMessage[];
  onAddMessage: (msg: ChatMessage) => void;
  sessionHistoryEvents: string[];
}

export default function AIEngineerPanel({
  favoriteDriver,
  favoriteTeam,
  sessionType,
  telemetryState,
  chatHistory,
  onAddMessage,
  sessionHistoryEvents,
}: AIEngineerPanelProps) {
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const samplePrompts = [
    `Why is ${favoriteDriver.code} losing time in sector 2?`,
    "Predict the next pit stop round and compound strategy.",
    "Compare qualifying pace to our primary rival grid pace.",
    `Analyze tire degradation curve on ${telemetryState.tireCompound} tires.`,
    "Is there an undercut opportunity right now?",
  ];

  // Auto scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatHistory, isTyping]);

  const handleSend = async (messageText: string) => {
    if (!messageText.trim()) return;

    const userMsg: ChatMessage = {
      id: `chat-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      role: "user",
      content: messageText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    };

    onAddMessage(userMsg);
    setInput("");
    setIsTyping(true);

    try {
      const response = await fetch("/api/engineer/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: messageText,
          driver: favoriteDriver.name,
          team: favoriteTeam.name,
          sessionType,
          telemetryState,
          chatHistory: chatHistory.slice(-6), // Send last 3 rounds of conversation
          sessionHistoryEvents,
        }),
      });

      if (!response.ok) {
        throw new Error("Telemetry link handshake rejected.");
      }

      const data = await response.json();
      const assistantMsg: ChatMessage = {
        id: `chat-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
        role: "assistant",
        content: data.response,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        status: data.warning ? "[LOCAL-SIM]" : "[RADIO-TRANSCRIPT]",
      };
      
      onAddMessage(assistantMsg);
    } catch (err) {
      const errorMsg: ChatMessage = {
        id: `chat-error-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
        role: "assistant",
        content: `"[RADIO STATIC] Telemetry packet failure. Check satellite server uplink. Copy that, we are monitoring tire heat manually. Box to confirm."`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        status: "[SYS-ERR]",
      };
      onAddMessage(errorMsg);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="bg-black/85 backdrop-blur-xl rounded-xl p-5 border border-zinc-800/80 flex flex-col h-full min-h-[480px] shadow-[0_4px_20px_rgba(0,0,0,0.5)] hover:border-red-500/10 transition-all" id="ai-engineer-container">
      {/* Pitwall Radio Header */}
      <div className="flex items-center justify-between pb-3 border-b border-zinc-900/60 mb-4">
        <div className="flex items-center gap-2">
          <div className="relative">
            <Radio className="w-4 h-4 text-red-500 animate-pulse" />
            <div className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping"></div>
          </div>
          <div>
            <h2 className="text-xs font-black tracking-widest text-zinc-150 uppercase font-sans flex items-center gap-1.5">
              AI Race Engineer
              <span className="text-[8px] bg-red-950 text-red-400 font-mono font-black px-1.5 py-0.5 rounded border border-red-900/40">PIT-RADIO</span>
            </h2>
            <p className="text-[8px] text-zinc-500 font-mono uppercase font-bold tracking-wider mt-0.5">Telemetry uplink active • {favoriteDriver.code}</p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 bg-zinc-950 border border-zinc-900 rounded py-1 px-2.5 shadow-inner">
          <Cpu className="w-3 h-3 text-zinc-500 animate-pulse" />
          <span className="text-[9px] text-zinc-400 font-mono font-bold tracking-wider uppercase">GEMINI CORE</span>
        </div>
      </div>

      {/* Messages Viewport */}
      <div className="flex-1 overflow-y-auto mb-4 p-3 bg-black/95 rounded border border-zinc-900/85 max-h-[380px] space-y-4 font-mono scrollbar-thin scrollbar-thumb-zinc-850 shadow-inner">
        {chatHistory.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-6 text-zinc-500">
            <Terminal className="w-6 h-6 text-zinc-700 mb-2" />
            <p className="text-[10px] font-bold uppercase tracking-widest font-mono text-zinc-400">PIT-GRID HANDSHAKE SECURE</p>
            <p className="text-[9px] text-zinc-650 mt-1 uppercase max-w-[280px] font-medium leading-relaxed">Select an active radio command below or input custom strategic queries directly into the cockpit telemetry stream.</p>
          </div>
        ) : (
          chatHistory.map((msg) => {
            const isUser = msg.role === "user";
            return (
              <div
                key={msg.id}
                className={`flex flex-col max-w-[85%] ${isUser ? "ml-auto items-end" : "mr-auto items-start"}`}
                id={`chat-msg-${msg.id}`}
              >
                {/* Meta details */}
                <div className="flex items-center gap-1.5 mb-1 text-[9px] font-bold tracking-wider">
                  {!isUser && (
                    <span 
                      className={`uppercase ${
                        msg.status === "[SYS-ERR]" ? "text-red-500 animate-pulse" : "text-emerald-500"
                      }`}
                    >
                      {msg.status || "[RADIO]"}
                    </span>
                  )}
                  <span className="text-zinc-600">{msg.timestamp}</span>
                  {isUser && <span className="text-zinc-500 uppercase">{favoriteDriver.code}</span>}
                </div>

                {/* Message Bubble */}
                <div
                  className={`rounded p-2.5 text-xs leading-relaxed border ${
                    isUser
                      ? "bg-zinc-900 text-slate-100 border-zinc-800"
                      : "bg-zinc-950/80 text-slate-200"
                  }`}
                  style={!isUser ? { borderColor: `${favoriteTeam.baseColor}44`, borderLeft: `3px solid ${favoriteTeam.baseColor}` } : {}}
                >
                  {/* Clean speech bubble structure */}
                  <p className="whitespace-pre-line font-medium text-zinc-300">{msg.content}</p>
                </div>
              </div>
            );
          })
        )}

        {/* Typing indicator */}
        {isTyping && (
          <div className="flex flex-col items-start mr-auto max-w-[85%]">
            <div className="flex items-center gap-1.5 mb-1 text-[9px] font-bold tracking-wider">
              <span className="text-emerald-500 uppercase animate-pulse">[PROCESSING COCKPIT TELEMETRY...]</span>
            </div>
            <div className="bg-zinc-950/80 text-slate-200 border border-zinc-900 rounded p-2.5 text-xs w-full">
              <div className="flex gap-1 items-center py-1">
                <span className="w-1 h-1 bg-red-600 rounded-full animate-bounce"></span>
                <span className="w-1 h-1 bg-red-600 rounded-full animate-bounce [animation-delay:0.2s]"></span>
                <span className="w-1 h-1 bg-red-600 rounded-full animate-bounce [animation-delay:0.4s]"></span>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Quick Prompts Grid */}
      <div className="mb-3">
        <span className="text-[8px] text-zinc-500 tracking-widest font-black uppercase mb-1.5 block font-mono">Suggested radio requests</span>
        <div className="flex flex-wrap gap-1.5">
          {samplePrompts.map((p, i) => (
            <button
              key={i}
              onClick={() => handleSend(p)}
              className="text-[9px] text-left text-zinc-400 bg-zinc-950 hover:bg-zinc-900 hover:text-white border border-zinc-900 rounded px-2 py-1.5 transition-all duration-150 line-clamp-1 uppercase tracking-wide font-mono font-semibold"
              id={`suggested-prompt-${i}`}
            >
              ⚡ {p}
            </button>
          ))}
        </div>
      </div>

      {/* Send Input Panel */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSend(input);
        }}
        className="relative flex items-center bg-zinc-950 rounded border border-zinc-900 p-1 font-mono focus-within:ring-1 focus-within:ring-red-500/80 focus-within:border-red-500/50 transition-all shadow-inner"
      >
        <span className="text-[9px] text-zinc-500 px-2 font-extrabold select-none uppercase tracking-widest">TX:</span>
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={`Transmit strategy update to ${favoriteDriver.name} cockpit...`}
          className="bg-transparent text-zinc-200 text-xs py-1.5 px-1 focus:outline-none flex-1 font-sans placeholder-zinc-650"
          id="chat-engineer-input"
        />
        <button
          type="submit"
          className="bg-red-600 hover:bg-red-500 text-white rounded px-2.5 py-1.5 text-[10px] font-black uppercase tracking-wider flex items-center gap-1 transition shadow-lg shadow-red-950/40"
          id="btn-send-message"
        >
          <Send className="w-3 h-3" />
          <span>TRANSMIT</span>
        </button>
      </form>
    </div>
  );
}

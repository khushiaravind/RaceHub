import { useState, useEffect, useRef } from "react";
import { 
  F1Driver, 
  F1Team, 
  TelemetryState, 
  TrackData, 
  ChatMessage, 
  StrategyResult, 
  PredictionsData, 
  InsightItem, 
  DRIVERS, 
  TEAMS, 
  TRACKS 
} from "./types";
import DriverCenter from "./components/DriverCenter";
import TrackMap from "./components/TrackMap";
import TelemetryDashboard from "./components/TelemetryDashboard";
import AIEngineerPanel from "./components/AIEngineerPanel";
import StrategyCenter from "./components/StrategyCenter";
import RacePredictionEngine from "./components/RacePredictionEngine";
import InsightsFeed from "./components/InsightsFeed";
import RacehubLogo from "./components/RacehubLogo";
import ChequeredDivider from "./components/ChequeredDivider";
import UserGuide from "./components/UserGuide";
import { 
  Play, 
  Zap, 
  Flag, 
  AlertOctagon, 
  XOctagon, 
  ShieldAlert, 
  Gauge, 
  Trophy, 
  Cpu, 
  RefreshCw, 
  MapPin, 
  Disc, 
  Volume2,
  Clock
} from "lucide-react";

// Track telemetry characteristics physics generator
function getTrackTelemetryAtPoint(trackId: string, index: number, totalPoints: number) {
  const ratio = index / totalPoints;

  let targetSpeed = 240;
  let rpm = 9800;
  let throttle = 80;
  let brake = 0;
  let gear = 5;
  let drsAvailable = false;

  if (trackId === "monaco") {
    // Monaco is twisty and slower
    const corners = [0.15, 0.3, 0.5, 0.72, 0.9];
    const isCorner = corners.some(c => Math.abs(ratio - c) < 0.08);

    if (isCorner) {
      targetSpeed = Math.round(55 + Math.random() * 25);
      rpm = Math.round(5100 + Math.random() * 400);
      throttle = 10;
      brake = Math.round(65 + Math.random() * 25);
      gear = 2;
    } else {
      targetSpeed = Math.round(210 + Math.random() * 30);
      rpm = Math.round(9200 + Math.random() * 800);
      throttle = Math.round(85 + Math.random() * 15);
      gear = Math.round(4 + Math.random() * 2);
      drsAvailable = ratio > 0.8 || ratio < 0.08;
    }
  } else if (trackId === "monza") {
    // Temple of Speed - Monza is ultra fast with high speed chicanes
    const corners = [0.15, 0.45, 0.7];
    const isCorner = corners.some(c => Math.abs(ratio - c) < 0.06);

    if (isCorner) {
      targetSpeed = Math.round(80 + Math.random() * 25);
      rpm = Math.round(6200 + Math.random() * 500);
      throttle = 0;
      brake = Math.round(85 + Math.random() * 10);
      gear = Math.round(2 + Math.random() * 1);
    } else {
      targetSpeed = Math.round(320 + Math.random() * 25);
      rpm = Math.round(12400 + Math.random() * 600);
      throttle = 100;
      gear = 8;
      drsAvailable = ratio > 0.78 || (ratio > 0.2 && ratio < 0.35);
    }
  } else if (trackId === "silverstone") {
    // Silverstone - Flowing high speed track
    const heavyCorners = [0.1, 0.4, 0.85];
    const isHeavyCorner = heavyCorners.some(c => Math.abs(ratio - c) < 0.07);

    if (isHeavyCorner) {
      targetSpeed = Math.round(120 + Math.random() * 30);
      rpm = Math.round(7800 + Math.random() * 600);
      throttle = 15;
      brake = Math.round(45 + Math.random() * 20);
      gear = 3;
    } else {
      targetSpeed = Math.round(285 + Math.random() * 35);
      rpm = Math.round(11100 + Math.random() * 1100);
      throttle = Math.round(90 + Math.random() * 10);
      gear = Math.round(6 + Math.random() * 2);
      drsAvailable = ratio > 0.45 && ratio < 0.65;
    }
  } else if (trackId === "spa") {
    // Spa Francorchamps - Long straights, Eau Rouge (fast), Bus Stop (slow)
    if (Math.abs(ratio - 0.12) < 0.05) {
      targetSpeed = Math.round(305 + Math.random() * 15);
      rpm = Math.round(12100 + Math.random() * 350);
      throttle = 100;
      brake = 0;
      gear = 8;
    } else if (Math.abs(ratio - 0.95) < 0.05) {
      targetSpeed = Math.round(75 + Math.random() * 15);
      rpm = Math.round(5900 + Math.random() * 400);
      throttle = 0;
      brake = 90;
      gear = 2;
    } else {
      const isCorner = [0.3, 0.5, 0.75].some(c => Math.abs(ratio - c) < 0.06);
      if (isCorner) {
        targetSpeed = Math.round(145 + Math.random() * 30);
        rpm = Math.round(8200 + Math.random() * 700);
        throttle = 25;
        brake = Math.round(30 + Math.random() * 20);
        gear = 4;
      } else {
        targetSpeed = Math.round(295 + Math.random() * 35);
        rpm = Math.round(11850 + Math.random() * 950);
        throttle = 100;
        gear = 7;
        drsAvailable = ratio < 0.08 || (ratio > 0.15 && ratio < 0.28);
      }
    }
  } else {
    // Suzuka / general default
    const corners = [0.15, 0.35, 0.55, 0.75, 0.9];
    const isCorner = corners.some(c => Math.abs(ratio - c) < 0.07);

    if (isCorner) {
      targetSpeed = Math.round(110 + Math.random() * 30);
      rpm = Math.round(7400 + Math.random() * 700);
      throttle = 15;
      brake = Math.round(40 + Math.random() * 25);
      gear = 3;
    } else {
      targetSpeed = Math.round(275 + Math.random() * 35);
      rpm = Math.round(11200 + Math.random() * 1200);
      throttle = Math.round(85 + Math.random() * 15);
      gear = Math.round(6 + Math.random() * 2);
      drsAvailable = ratio > 0.92 || ratio < 0.05;
    }
  }

  return { targetSpeed, rpm, throttle, brake, gear, drsAvailable };
}

export default function App() {
  // --------------------------------------------------------------------------
  // CORE STATE
  // --------------------------------------------------------------------------
  const [favoriteDriver, setFavoriteDriver] = useState<F1Driver>(DRIVERS[0]); // Default Max Verstappen
  const [comparisonDriver, setComparisonDriver] = useState<F1Driver>(DRIVERS[1]); // Default Lando Norris
  const [favoriteTeam, setFavoriteTeam] = useState<F1Team>(TEAMS["Red Bull Racing"]);
  const [selectedTrack, setSelectedTrack] = useState<TrackData>(TRACKS[0]); // Default Monaco
  const [sessionType, setSessionType] = useState<"Practice" | "Qualifying" | "Race">("Race");
  const [sessionStatus, setSessionStatus] = useState<"Green Flag" | "Safety Car" | "Red Flag">("Green Flag");

  // Track position indicator index
  const [carPositionIndex, setCarPositionIndex] = useState(0);

  // Session History events log for AI persistent engineer memory
  const [sessionHistoryEvents, setSessionHistoryEvents] = useState<string[]>([
    "Session initialized under Race format"
  ]);

  // Telemetry Snapshot
  const [telemetry, setTelemetry] = useState<TelemetryState>({
    speed: 285,
    rpm: 11450,
    throttle: 85,
    brake: 0,
    gear: 6,
    drs: false,
    tireCompound: "Medium",
    tireAge: 12,
    tireWear: 18.5,
    fuelLoad: 68.4,
    currentLap: 14,
    lastLapTime: "01:15.110",
    bestLapTime: "01:14.920",
    s1: "28.140",
    s2: "33.520",
    s3: "21.110",
    lapDelta: -0.045
  });

  // Rolling telemetry history for Recharts traces
  const [telemetryHistory, setTelemetryHistory] = useState<any[]>([]);
  // Individual completed laps log data for progress graph
  const [lapHistory, setLapHistory] = useState<any[]>([]);

  // Strategy simulation results state
  const [strategyOutput, setStrategyOutput] = useState<StrategyResult | null>(null);
  const [isSimulatingStrategy, setIsSimulatingStrategy] = useState(false);

  // Predictions State
  const [predictions, setPredictions] = useState<PredictionsData>({
    winProb: 65,
    podiumProb: 88,
    top5Prob: 95,
    expectedFinish: 1
  });

  // AI Chat History
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([
    {
      id: "init",
      role: "assistant",
      content: "Uplink to pit wall authenticated. Dynamic telemetry traces are streaming. Drivers and strategist teams are locked in. Stand by for real-time optimal strategy recommendations.",
      timestamp: "03:54:31",
      status: "[SYS-STB]"
    }
  ]);

  // Insights Feed Log
  const [insights, setInsights] = useState<InsightItem[]>([
    { id: "1", type: "info", message: "Telemetry session active. Red Bull Racing core logic syncing.", timestamp: "03:54:31" },
    { id: "2", type: "strategy", message: "Initial undercut threshold calculated: Gap to Lando Norris is -1.4 seconds.", timestamp: "03:54:40" },
  ]);

  // UI state comparisons toggle
  const [isCompareMode, setIsCompareMode] = useState(false);

  // UTC Live Clock
  const [liveClock, setLiveClock] = useState("");

  const chatHandledRef = useRef<Record<string, boolean>>({});

  // --------------------------------------------------------------------------
  // LIVE CLOCK & SETUP INITIAL HISTORY
  // --------------------------------------------------------------------------
  useEffect(() => {
    // Generate initial history points so graphs don't start blank
    const initialPoints = Array.from({ length: 15 }).map((_, i) => ({
      speed: Math.round(220 + Math.random() * 80),
      rpm: Math.round(10500 + Math.random() * 1500),
      throttle: Math.round(60 + Math.random() * 40),
      brake: Math.random() > 0.75 ? Math.round(40 + Math.random() * 40) : 0,
    }));
    setTelemetryHistory(initialPoints);

    // Initial Lap History
    setLapHistory([
      { lap: 1, delta: 0.15 },
      { lap: 2, delta: 0.12 },
      { lap: 3, delta: -0.05 },
      { lap: 4, delta: -0.01 },
      { lap: 5, delta: 0.08 },
      { lap: 6, delta: 0.04 },
      { lap: 7, delta: -0.12 },
      { lap: 8, delta: -0.09 },
      { lap: 9, delta: 0.02 },
      { lap: 10, delta: -0.03 },
      { lap: 11, delta: 0.14 },
      { lap: 12, delta: 0.08 },
      { lap: 13, delta: -0.02 },
    ]);

    // Setup live clock
    const clockInterval = setInterval(() => {
      const now = new Date();
      setLiveClock(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) + " UTC");
    }, 1000);

    // Initial strategy simulation run
    runStrategySimulation();

    return () => clearInterval(clockInterval);
  }, []);

  // --------------------------------------------------------------------------
  // PERIODIC SIMULATION ENGINE (1Hz)
  // --------------------------------------------------------------------------
  useEffect(() => {
    const simInterval = setInterval(() => {
      // 1. Advance track index
      let nextIndex = 0;
      setCarPositionIndex((prevIndex) => {
        const totalPoints = selectedTrack.racingLinePoints.length;
        nextIndex = (prevIndex + 1) % totalPoints;
        return nextIndex;
      });

      // 2. Compute physics parameters based on next index
      setTelemetry((prev) => {
        const isLapCompleted = nextIndex === 0;

        let newSpeed = prev.speed;
        let newRPM = prev.rpm;
        let newThrottle = prev.throttle;
        let newBrake = prev.brake;
        let newGear = prev.gear;
        let newDrs = prev.drs;
        let newFuel = prev.fuelLoad;
        let newTireAge = prev.tireAge;
        let newTireWear = prev.tireWear;

        // get track characteristics
        const physics = getTrackTelemetryAtPoint(selectedTrack.id, nextIndex, selectedTrack.racingLinePoints.length);

        if (sessionStatus === "Safety Car") {
          newSpeed = Math.round(100 + Math.random() * 15);
          newRPM = Math.round(5200 + Math.random() * 400);
          newThrottle = Math.round(18 + Math.random() * 10);
          newBrake = Math.random() > 0.85 ? Math.round(15 + Math.random() * 15) : 0;
          newGear = Math.random() > 0.85 ? 3 : 4;
          newDrs = false;
        } else if (sessionStatus === "Red Flag") {
          newSpeed = 0;
          newRPM = 0;
          newThrottle = 0;
          newBrake = 100;
          newGear = 0;
          newDrs = false;
        } else {
          // Green flag physics mapping
          newSpeed = Math.round(physics.targetSpeed + (Math.random() * 12 - 6));
          newRPM = Math.round(physics.rpm + (Math.random() * 300 - 150));
          newThrottle = physics.throttle;
          newBrake = physics.brake;
          newGear = physics.gear;
          newDrs = physics.drsAvailable;
        }

        // Fuel decay & tire degradation rates based on track abrasiveness
        const abrasiveness = selectedTrack.id === "monaco" ? 0.9 :
                             selectedTrack.id === "monza" ? 0.8 :
                             selectedTrack.id === "silverstone" ? 1.4 :
                             selectedTrack.id === "spa" ? 1.1 : 1.5;

        const baseWearRate = prev.tireCompound === "Soft" ? 0.45 :
                             prev.tireCompound === "Medium" ? 0.28 : 0.16;

        let sessionWearMultiplier = 1.0;
        if (sessionType === "Practice") {
          sessionWearMultiplier = 0.55;
          newFuel = Math.max(5, Number((prev.fuelLoad - 0.04).toFixed(3)));
          newTireAge = prev.tireAge + 0.02;
        } else if (sessionType === "Qualifying") {
          sessionWearMultiplier = 1.8;
          newFuel = Math.max(1.5, Number((prev.fuelLoad - 0.10).toFixed(3)));
          newTireAge = prev.tireAge + 0.05;
        } else {
          sessionWearMultiplier = 1.15;
          newFuel = Math.max(2.0, Number((prev.fuelLoad - 0.15).toFixed(3)));
          newTireAge = prev.tireAge + 0.06;
        }

        if (sessionStatus === "Safety Car") {
          sessionWearMultiplier *= 0.4;
          newFuel = Math.max(2.0, Number((prev.fuelLoad - 0.05).toFixed(3)));
        } else if (sessionStatus === "Red Flag") {
          sessionWearMultiplier = 0;
          newFuel = prev.fuelLoad;
        }

        const wearIncrement = baseWearRate * abrasiveness * sessionWearMultiplier;
        newTireWear = Math.min(100, Number((prev.tireWear + wearIncrement).toFixed(3)));

        // Lap progression tracking
        let currentLap = prev.currentLap;
        let lastLapTime = prev.lastLapTime;
        let bestLapTime = prev.bestLapTime;
        let s1 = prev.s1;
        let s2 = prev.s2;
        let s3 = prev.s3;

        if (isLapCompleted) {
          currentLap = prev.currentLap + 1;
          
          let baseSec = 87;
          if (selectedTrack.id === "monza") baseSec = 81.2;
          else if (selectedTrack.id === "monaco") baseSec = 73.1;
          else if (selectedTrack.id === "silverstone") baseSec = 87.1;
          else if (selectedTrack.id === "spa") baseSec = 106.3;
          else if (selectedTrack.id === "suzuka") baseSec = 91.0;

          const wearPenalty = (prev.tireWear / 100) * 3.8;
          const scPenalty = sessionStatus === "Safety Car" ? 35.0 : 0;
          const lapTimeInSeconds = baseSec + wearPenalty + scPenalty + (Math.random() * 0.5 - 0.25);

          const formatLapTime = (sec: number) => {
            const m = Math.floor(sec / 60);
            const s = Math.floor(sec % 60);
            const ms = Math.floor((sec % 1) * 1000);
            return `${m.toString().padStart(2, "0")}:${s.toString().padStart(2, "0")}.${ms.toString().padStart(3, "0")}`;
          };

          lastLapTime = formatLapTime(lapTimeInSeconds);

          if (bestLapTime === "01:15.110" || bestLapTime === "00:00.000") {
            bestLapTime = lastLapTime;
          } else {
            const parseLap = (lStr: string) => {
              const [m, rest] = lStr.split(":");
              const [s, ms] = rest.split(".");
              return Number(m) * 60 + Number(s) + Number(ms) / 1000;
            };
            try {
              if (lapTimeInSeconds < parseLap(bestLapTime) && sessionStatus === "Green Flag") {
                bestLapTime = lastLapTime;
              }
            } catch (e) {
              bestLapTime = lastLapTime;
            }
          }

          s1 = (lapTimeInSeconds * 0.33 + (Math.random() * 0.15 - 0.07)).toFixed(3);
          s2 = (lapTimeInSeconds * 0.42 + (Math.random() * 0.15 - 0.07)).toFixed(3);
          s3 = (lapTimeInSeconds * 0.25 + (Math.random() * 0.15 - 0.07)).toFixed(3);

          setLapHistory((prevHist) => [
            ...prevHist,
            { lap: currentLap - 1, delta: Number((lapTimeInSeconds - baseSec).toFixed(3)) }
          ]);

          setSessionHistoryEvents((events) => [
            ...events,
            `Lap ${currentLap - 1} completed: time ${lastLapTime}, tyre wear ${Math.round(newTireWear)}%.`
          ]);

          const lapInsight: InsightItem = {
            id: `lap-ins-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
            type: "performance",
            message: `Lap ${currentLap - 1} Completed: ${favoriteDriver.code} registered a lap of ${lastLapTime} (Wear: ${Math.round(newTireWear)}%).`,
            timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })
          };
          setInsights((pi) => [lapInsight, ...pi]);
        }

        // Accumulate speed curves
        setTelemetryHistory((hist) => {
          const nextHist = [...hist, { speed: newSpeed, rpm: newRPM, throttle: newThrottle, brake: newBrake }];
          if (nextHist.length > 20) {
            nextHist.shift();
          }
          return nextHist;
        });

        return {
          ...prev,
          speed: newSpeed,
          rpm: newRPM,
          throttle: newThrottle,
          brake: newBrake,
          gear: newGear,
          drs: newDrs,
          fuelLoad: newFuel,
          tireAge: Math.round(newTireAge),
          tireWear: newTireWear,
          currentLap,
          lastLapTime,
          bestLapTime,
          s1,
          s2,
          s3,
          lapDelta: Number((-0.18 + Math.random() * 0.35).toFixed(3))
        };
      });

    }, 1000);

    return () => clearInterval(simInterval);
  }, [selectedTrack, sessionStatus, sessionType]);

  // --------------------------------------------------------------------------
  // RANDOM INSIGHT POPULATION ENGINE
  // --------------------------------------------------------------------------
  const triggerRandomInsight = (wearPercent: number) => {
    const triggers = [
      { type: "performance", text: `${favoriteDriver.name} is hitting early throttle points, gaining 0.082s at the peak of Turn 8.` },
      { type: "strategy", text: `Pit lane feedback confirms clean air in the exit window. Prepare underlap window plans.` },
      { type: "warning", text: `Competitor tyre wear is rising rapidly. DRS disadvantage is predicted on the next straight.` },
      { type: "info", text: "Fuel flow and thermal efficiency values are within optimal ranges." },
      { type: "performance", text: `High speed balance looking solid. Dynamic aero load shows favorable front apex wing angles.` },
      { type: "warning", text: `Rear brake system is running hot at 750°C. Monitor caliper feedback.` }
    ];

    if (wearPercent > 55) {
      triggers.push({ type: "warning", text: `CRITICAL TIRE DEGRADATION warning: Front Left core carcass has surpassed 55% wear threshold.` });
    }

    const picked = triggers[Math.floor(Math.random() * triggers.length)];
    const newInsight: InsightItem = {
      id: `insight-rand-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      type: picked.type as any,
      message: picked.text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    };

    setInsights((prev) => [newInsight, ...prev.slice(0, 15)]);
  };

  // --------------------------------------------------------------------------
  // RUN MONTE CARLO STRATEGY SIMULATOR
  // --------------------------------------------------------------------------
  const runStrategySimulation = () => {
    setIsSimulatingStrategy(true);

    setTimeout(() => {
      const currentCmp = telemetry.tireCompound;
      let sequence: string[] = [];
      let recLap = 24;
      let altLap = 30;

      if (currentCmp === "Soft") {
        sequence = ["Soft", "Medium", "Hard"];
        recLap = 16;
        altLap = 21;
      } else if (currentCmp === "Medium") {
        sequence = ["Medium", "Hard"];
        recLap = 26;
        altLap = 32;
      } else {
        sequence = ["Hard", "Soft"];
        recLap = 33;
        altLap = 38;
      }

      const simResult: StrategyResult = {
        recommendedLap: recLap,
        alternativeLap: altLap,
        compoundSequence: sequence,
        undercutLapDelta: Number((1.2 + Math.random() * 0.9).toFixed(2)),
        overcutLapDelta: Number((0.4 + Math.random() * 0.5).toFixed(2)),
        expectedFinishingPos: Math.max(1, favoriteDriver.championshipPosition - (Math.random() > 0.6 ? 1 : 0)),
        successProbability: Math.min(99, Math.round(78 + Math.random() * 21)),
        pitstopDurationLoss: 22.4,
      };

      setStrategyOutput(simResult);
      setIsSimulatingStrategy(false);

      setPredictions({
        winProb: Math.round(simResult.successProbability * 0.8),
        podiumProb: Math.min(100, Math.round(simResult.successProbability * 1.1)),
        top5Prob: Math.min(100, Math.round(simResult.successProbability * 1.25)),
        expectedFinish: simResult.expectedFinishingPos,
      });

      // Log Strategy simulation
      setSessionHistoryEvents((events) => [
        ...events,
        `Monte Carlo Strategy simulation executed: recommended pit stop Lap ${recLap}, predicted finishing rank P${simResult.expectedFinishingPos}.`
      ]);

      const insightSim: InsightItem = {
        id: `insight-sim-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
        type: "strategy",
        message: `Monte Carlo strategy simulation executed. Target pit stop window calculated on Lap ${recLap}. Predicted finishing rank: P${simResult.expectedFinishingPos}.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      };
      setInsights((prev) => [insightSim, ...prev]);

    }, 1500);
  };

  // --------------------------------------------------------------------------
  // SESSION CONTROL BUTTON HANDLERS
  // --------------------------------------------------------------------------
  const selectSession = (type: "Practice" | "Qualifying" | "Race") => {
    setSessionType(type);
    let newCompound: "Soft" | "Medium" | "Hard" = "Medium";

    if (type === "Qualifying") {
      newCompound = "Soft";
    }

    setTelemetry((prev) => ({
      ...prev,
      fuelLoad: type === "Qualifying" ? 12.5 : type === "Practice" ? 45 : 105.0,
      tireCompound: newCompound,
      tireAge: type === "Qualifying" ? 1 : type === "Practice" ? 3 : 14,
      tireWear: type === "Qualifying" ? 5 : type === "Practice" ? 10 : 22,
    }));

    setStrategyOutput(null);

    setSessionHistoryEvents((events) => [
      ...events,
      `Session transitioned to ${type.toUpperCase()} format. Fuel load and default tyre specs loaded.`
    ]);

    const sessInsight: InsightItem = {
      id: `insight-session-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      type: "info",
      message: `Session format shifted to ${type.toUpperCase()}. Dynamic parameters adjusted. Active compounds: ${newCompound}.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    };
    setInsights((prev) => [sessInsight, ...prev]);
  };

  const selectSafetyCar = () => {
    setSessionStatus("Safety Car");
    
    setSessionHistoryEvents((events) => [
      ...events,
      `Safety Car deployed on Lap ${telemetry.currentLap}. Delta constraints active.`
    ]);

    const carInsight: InsightItem = {
      id: `insight-safety-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      type: "warning",
      message: `[FLAG WARNING] SAFETY CAR DEPLOYED. Maintain delta targets immediately. Speeds capped at 120 km/h. Pit lane open.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    };
    setInsights((prev) => [carInsight, ...prev]);
  };

  const selectRedFlag = () => {
    setSessionStatus("Red Flag");

    setSessionHistoryEvents((events) => [
      ...events,
      `Red Flag called on Lap ${telemetry.currentLap}. Session suspended.`
    ]);

    const carInsight: InsightItem = {
      id: `insight-red-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      type: "warning",
      message: `[CRITICAL WARNING] RED FLAG. Bring vehicle back to pitlane queue immediately. Session suspended.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    };
    setInsights((prev) => [carInsight, ...prev]);
  };

  const restartSession = () => {
    setSessionStatus("Green Flag");
    setCarPositionIndex(0);
    setTelemetry({
      speed: 285,
      rpm: 11450,
      throttle: 85,
      brake: 0,
      gear: 6,
      drs: false,
      tireCompound: "Medium",
      tireAge: 1,
      tireWear: 2,
      fuelLoad: sessionType === "Race" ? 105 : sessionType === "Practice" ? 50 : 14,
      currentLap: 1,
      lastLapTime: "01:15.340",
      bestLapTime: "01:15.120",
      s1: "28.140",
      s2: "33.520",
      s3: "21.110",
      lapDelta: 0.0
    });

    setSessionHistoryEvents([
      "Session restarted, fresh timing logs and standard fuel mass initialized."
    ]);

    const carInsight: InsightItem = {
      id: `insight-restart-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      type: "info",
      message: `Session restarted. Timing logs and fuel levels defaulted for fresh telemetry recording.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    };
    setInsights((prev) => [carInsight, ...prev]);
  };

  const executePitStop = (compound: "Soft" | "Medium" | "Hard") => {
    setTelemetry((prev) => {
      const updatedSnapshot: TelemetryState = {
        ...prev,
        tireCompound: compound,
        tireAge: 1,
        tireWear: 0.0,
        lapDelta: Number((prev.lapDelta + 22.4).toFixed(3))
      };

      setSessionHistoryEvents((events) => [
        ...events,
        `Box box: pit stop executed on Lap ${prev.currentLap}. Swapped to fresh ${compound} tyres.`
      ]);

      const pitInsight: InsightItem = {
        id: `pit-ins-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        type: "strategy",
        message: `[PIT WALL] BOX BOX confirmed. Swapped to a brand new set of ${compound} tyres on Lap ${prev.currentLap}. Pit stop duration: 2.44s.`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      };
      setInsights((pi) => [pitInsight, ...pi]);

      const botMessage: ChatMessage = {
        id: `pit-bot-${Date.now()}`,
        role: "assistant",
        content: `**[RADIO TRANSMISSION]** "Box box confirmed. Successful stop. We fitted a set of fresh **${compound}** compounds. Clear track ahead, push now. Delta is +22.4s."`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
        status: "[PIT-SYS]"
      };
      setChatHistory((chat) => [...chat, botMessage]);

      return updatedSnapshot;
    });
  };

  // Add Message Handler (Chat Panel)
  const handleAddChatMessage = (msg: ChatMessage) => {
    setChatHistory((prev) => [...prev, msg]);
  };

  const s1End = Math.floor(selectedTrack.racingLinePoints.length * 0.33);
  const s2End = Math.floor(selectedTrack.racingLinePoints.length * 0.66);

  let activeSector: "S1" | "S2" | "S3" = "S1";
  if (carPositionIndex >= s1End && carPositionIndex < s2End) {
    activeSector = "S2";
  } else if (carPositionIndex >= s2End) {
    activeSector = "S3";
  }

  // --------------------------------------------------------------------------
  // RENDER MAIN APPLICATION LAYOUT
  // --------------------------------------------------------------------------
  return (
    <div 
      className="min-h-screen bg-black text-slate-100 flex flex-col font-sans selection:bg-red-600 selection:text-white carbon-grid scanlines"
      id="racehub-application-root"
    >
      {/* HEADER SECTION */}
      <header className="border-b border-zinc-800/60 bg-black/85 backdrop-blur-xl sticky top-0 z-50 py-3 px-4 md:px-6 grid grid-cols-1 md:grid-cols-3 items-center gap-4" id="app-header">
        {/* Left Column: Workstation Title */}
        <div className="flex items-center gap-3 justify-start">
          <div>
            <h1 className="text-xs font-black tracking-widest text-zinc-150 flex items-center gap-1.5 font-sans uppercase">
              PIT WALL TELEMETRY WORKSTATION
            </h1>
            <p className="text-[9px] font-mono text-zinc-500 uppercase tracking-widest hidden sm:block">
              Uplink: Live Satellite Connection // Terminal-B
            </p>
          </div>
        </div>

        {/* Center Column: Centered RACEHUB Logo */}
        <div className="flex justify-center items-center" id="brand-logo-centered">
          <RacehubLogo />
        </div>

        {/* Right Column: Clock, Delta & Safety Flag */}
        <div className="flex items-center gap-3 md:justify-end justify-between w-full md:w-auto">
          {/* Global timing delta bar */}
          <div className="hidden lg:flex items-center gap-2 bg-zinc-950/85 border border-zinc-900 rounded-md py-1 px-2 shadow-inner">
            <div className="flex items-center gap-1 text-[8px] uppercase font-mono">
              <span className="text-zinc-500 font-bold">S1</span>
              <span className={`font-extrabold tracking-wide px-1 py-0.5 rounded border transition-all duration-300 ${
                activeSector === "S1" 
                  ? "bg-emerald-950 text-emerald-400 border-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.45)]" 
                  : "bg-zinc-900/60 text-zinc-405 border-zinc-850"
              }`}>
                {telemetry.s1}
              </span>
            </div>
            <div className="h-3 w-px bg-zinc-800" />
            <div className="flex items-center gap-1 text-[8px] uppercase font-mono">
              <span className="text-zinc-500 font-bold">S2</span>
              <span className={`font-extrabold tracking-wide px-1 py-0.5 rounded border transition-all duration-300 ${
                activeSector === "S2" 
                  ? "bg-emerald-950 text-emerald-400 border-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.45)]" 
                  : "bg-zinc-900/60 text-zinc-405 border-zinc-850"
              }`}>
                {telemetry.s2}
              </span>
            </div>
            <div className="h-3 w-px bg-zinc-800" />
            <div className="flex items-center gap-1 text-[8px] uppercase font-mono">
              <span className="text-zinc-500 font-bold">S3</span>
              <span className={`font-extrabold tracking-wide px-1 py-0.5 rounded border transition-all duration-300 ${
                activeSector === "S3" 
                  ? "bg-emerald-950 text-emerald-400 border-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.45)]" 
                  : "bg-zinc-900/60 text-zinc-405 border-zinc-850"
              }`}>
                {telemetry.s3}
              </span>
            </div>
          </div>

          <div className="h-4 w-px bg-zinc-800 hidden lg:block" />

          {/* UTC Clock */}
          <div className="flex items-center gap-1.5 text-xs text-zinc-400 font-mono">
            <Clock className="w-3.5 h-3.5 text-zinc-500" />
            <span>{liveClock || "03:54:31 UTC"}</span>
          </div>

          <div className="h-4 w-px bg-zinc-800 hidden sm:block" />

          {/* Core Flag indicator */}
          <div className="flex items-center gap-2">
            <span 
              className={`px-2.5 py-1 rounded text-xs font-mono font-bold uppercase border animate-pulse ${
                sessionStatus === "Green Flag" 
                  ? "bg-emerald-950/80 text-emerald-400 border-emerald-900/60" 
                  : sessionStatus === "Safety Car" 
                  ? "bg-yellow-950/80 text-yellow-400 border-yellow-900/60" 
                  : "bg-red-950/80 text-red-400 border-red-900/60"
              }`}
            >
              {sessionStatus}
            </span>
          </div>
        </div>
      </header>

      <ChequeredDivider />

      {/* SESSION SPEED ACTIONS BAR */}
      <div className="bg-black/45 border-b border-zinc-800/50 backdrop-blur-md py-3 px-4 md:px-6 flex flex-wrap items-center justify-between gap-4" id="controls-topbar">
        {/* Format Selectors */}
        <div className="flex items-center gap-2">
          <span className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider font-mono">Format:</span>
          <button
            onClick={() => selectSession("Practice")}
            className={`px-3 py-1 rounded text-xs font-semibold uppercase tracking-wider transition-all ${
              sessionType === "Practice"
                ? "bg-zinc-800 text-zinc-100 border border-zinc-700"
                : "text-zinc-400 hover:text-zinc-200"
            }`}
            id="btn-session-practice"
          >
            Practice (FP3)
          </button>
          <button
            onClick={() => selectSession("Qualifying")}
            className={`px-3 py-1 rounded text-xs font-semibold uppercase tracking-wider transition-all ${
              sessionType === "Qualifying"
                ? "bg-orange-600 text-white border border-orange-500 shadow-md shadow-orange-950/30"
                : "text-zinc-400 hover:text-zinc-250"
            }`}
            id="btn-session-qualifying"
          >
            Qualifying (Q3)
          </button>
          <button
            onClick={() => selectSession("Race")}
            className={`px-3 py-1 rounded text-xs font-semibold uppercase tracking-wider transition-all ${
              sessionType === "Race"
                ? "bg-red-650 text-white border border-zinc-700"
                : "text-zinc-400 hover:text-zinc-250"
            }`}
            id="btn-session-race"
          >
            Race (GP)
          </button>
        </div>

        {/* Incident controls */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-[10px] text-zinc-400 font-bold uppercase tracking-wider font-mono">Pitwall Actions:</span>
          <button
            onClick={selectSafetyCar}
            className={`px-2.5 py-1 rounded text-xs font-bold font-mono uppercase bg-yellow-950/60 border border-yellow-900/50 text-yellow-400 hover:bg-yellow-900/30 transition-all ${
              sessionStatus === "Safety Car" ? "ring-1 ring-yellow-500" : ""
            }`}
            id="btn-trigger-safety-car"
          >
            ⚠️ Safety Car
          </button>
          <button
            onClick={selectRedFlag}
            className={`px-2.5 py-1 rounded text-xs font-bold font-mono uppercase bg-red-950/60 border border-red-900/50 text-red-500 hover:bg-red-900/30 transition-all ${
              sessionStatus === "Red Flag" ? "ring-1 ring-red-500" : ""
            }`}
            id="btn-trigger-red-flag"
          >
            🛑 Red Flag
          </button>
          <button
            onClick={restartSession}
            className="px-2.5 py-1 rounded text-xs font-bold font-mono uppercase bg-zinc-900 hover:bg-zinc-850 border border-zinc-800 text-zinc-350 transition-all"
            id="btn-trigger-restart"
          >
            🔄 Restart
          </button>

          <span className="h-4 w-px bg-zinc-850 mx-1" />
          <span className="text-[10px] text-zinc-450 font-bold uppercase tracking-wider font-mono">Box Box:</span>
          <div className="flex items-center gap-1 bg-zinc-950/80 border border-zinc-900 rounded p-0.5">
            <button
              onClick={() => executePitStop("Soft")}
              className="px-1.5 py-0.5 rounded text-[9px] font-mono font-bold bg-red-950/50 border border-red-900/40 text-red-400 hover:bg-red-900/30 transition-all"
              id="btn-box-soft"
            >
              S Fresh
            </button>
            <button
              onClick={() => executePitStop("Medium")}
              className="px-1.5 py-0.5 rounded text-[9px] font-mono font-bold bg-yellow-950/50 border border-yellow-900/40 text-yellow-450 hover:bg-yellow-900/30 transition-all"
              id="btn-box-medium"
            >
              M Fresh
            </button>
            <button
              onClick={() => executePitStop("Hard")}
              className="px-1.5 py-0.5 rounded text-[9px] font-mono font-bold bg-zinc-900 border border-zinc-800 text-zinc-200 hover:bg-zinc-855 transition-all"
              id="btn-box-hard"
            >
              H Fresh
            </button>
          </div>
        </div>
      </div>

      <ChequeredDivider />

      {/* CORE FRAMEWORK WORKSPACE */}
      <div className="flex-1 grid grid-cols-1 xl:grid-cols-12 gap-5 p-4 md:p-6" id="app-workspace-body">
        
        {/* LEFT COLUMN: TELEMETRY SIDEBAR (3 Channels) */}
        <div className="xl:col-span-3 flex flex-col gap-5 order-2 xl:order-1">
          {/* Driver profile module */}
          <DriverCenter
            favoriteDriver={favoriteDriver}
            comparisonDriver={comparisonDriver}
            favoriteTeam={favoriteTeam}
            isCompareMode={isCompareMode}
            onSelectFavoriteDriver={setFavoriteDriver}
            onSelectComparisonDriver={setComparisonDriver}
            onSelectFavoriteTeam={setFavoriteTeam}
            onToggleCompareMode={setIsCompareMode}
          />

          {/* Interactive track mapping */}
          <TrackMap
            selectedTrack={selectedTrack}
            onSelectTrack={(t) => {
              setSelectedTrack(t);
              setCarPositionIndex(0);
              setSessionHistoryEvents((events) => [
                ...events,
                `Track transitioned to ${t.name} (${t.country}). Optimal layout loaded.`
              ]);
            }}
            activeTeam={favoriteTeam}
            currentSpeed={telemetry.speed}
            carPositionIndex={carPositionIndex}
          />
        </div>

        {/* CENTRAL ANALYSIS WORKSPACE (5 Channels) */}
        <div className="xl:col-span-5 flex flex-col gap-5 order-1 xl:order-2">
          {/* Main live metrics & charts */}
          <TelemetryDashboard
            telemetryState={telemetry}
            activeTeam={favoriteTeam}
            activeDriver={favoriteDriver}
            historyData={telemetryHistory}
            lapProgressionData={lapHistory}
          />

          {/* Strategy center & Prediction models side-by-side */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <StrategyCenter
              telemetryState={telemetry}
              activeTeam={favoriteTeam}
              activeDriver={favoriteDriver}
              onRunSimulation={runStrategySimulation}
              strategyOutput={strategyOutput}
              isSimulating={isSimulatingStrategy}
            />

            <RacePredictionEngine
              predictionData={predictions}
              activeTeam={favoriteTeam}
              activeDriver={favoriteDriver}
            />
          </div>

          {/* Onboarding Operational Manual */}
          <UserGuide />
        </div>

        {/* RIGHT COLUMN: AI RACE ENGINEER CHANNEL (4 Channels) */}
        <div className="xl:col-span-4 flex flex-col gap-5 order-3 xl:order-3">
          {/* Chat Panel with F1 engine */}
          <AIEngineerPanel
            favoriteDriver={favoriteDriver}
            favoriteTeam={favoriteTeam}
            sessionType={sessionType}
            telemetryState={telemetry}
            chatHistory={chatHistory}
            onAddMessage={handleAddChatMessage}
            sessionHistoryEvents={sessionHistoryEvents}
          />

          {/* Live scrolling insights logs */}
          <InsightsFeed
            insights={insights}
          />
        </div>

      </div>

      <ChequeredDivider />

      {/* BOTTOM TICK STRIP */}
      <footer className="border-t border-zinc-900 bg-neutral-950/95 py-2.5 px-4 text-xs font-mono text-zinc-500 uppercase flex flex-col sm:flex-row items-center justify-between gap-2" id="bottom-strip">
        <div className="flex flex-wrap items-center gap-4">
          <span className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            TELEMETRY BROADCAST
          </span>
          <span className="text-zinc-800">|</span>
          <span className="text-zinc-400">LAP: {telemetry.currentLap} / 71</span>
          <span className="text-zinc-800">|</span>
          <span className="text-zinc-400">P-TIME DELTA: <span className="text-emerald-400">{telemetry.lapDelta > 0 ? `+${telemetry.lapDelta}` : telemetry.lapDelta}s</span></span>
          <span className="text-zinc-800">|</span>
          <span className="text-zinc-400">FUEL DECAY: {telemetry.fuelLoad.toFixed(2)} kg</span>
        </div>
        <div>
          <span>ORACLE CLOUD RUN TELEMETRY PLATFORM © 2026</span>
        </div>
      </footer>
    </div>
  );
}

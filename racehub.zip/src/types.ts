export interface F1Driver {
  id: string;
  name: string;
  number: number;
  nationality: string;
  team: string;
  championshipPosition: number;
  points: number;
  wins: number;
  podiums: number;
  polePositions: number;
  fastestLaps: number;
  code: string; // e.g. "VER"
  avatarPlaceholder: string; // solid bg color
}

export interface F1Team {
  name: string;
  baseColor: string; // hex
  secondaryColor: string; // hex
  accentColor: string; // hex for glows
  glowColor: string; // tailwind glow color
  textColor: string; // tailwind friendly text
  logoChar: string; // single char or symbol
  description: string;
  dominantColorClass: string; // e.g. "papaya"
}

export interface TelemetryState {
  speed: number;
  rpm: number;
  throttle: number;
  brake: number;
  gear: number;
  drs: boolean;
  tireCompound: "Soft" | "Medium" | "Hard" | "Wet" | "Inters";
  tireAge: number;
  tireWear: number; // percentage
  fuelLoad: number; // kg
  currentLap: number;
  lastLapTime: string;
  bestLapTime: string;
  s1: string; // e.g. "28.140"
  s2: string; // e.g. "33.520"
  s3: string; // e.g. "21.110"
  lapDelta: number; // live timing compared to best
}

export interface TrackData {
  id: string;
  name: string;
  country: string;
  length: string; // "5.891 km"
  turns: number;
  lapRecord: string; // "1:27.097 (Hamilton, 2020)"
  difficulty: "High" | "Medium" | "Extreme" | "Technical";
  optimalStrategy: string;
  sectorsCount: number;
  racingLinePoints: { x: number; y: number }[]; // coordinates for rendering track SVG
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
  status?: string; // [SYS], [RAD], etc
}

export interface StrategyResult {
  recommendedLap: number;
  alternativeLap: number;
  compoundSequence: string[];
  undercutLapDelta: number;
  overcutLapDelta: number;
  expectedFinishingPos: number;
  successProbability: number;
  pitstopDurationLoss: number;
}

export interface PredictionsData {
  winProb: number;
  podiumProb: number;
  top5Prob: number;
  expectedFinish: number;
}

export interface InsightItem {
  id: string;
  type: "warning" | "performance" | "strategy" | "info";
  message: string;
  timestamp: string;
}

// --------------------------------------------------------------------------
// DRIvER DATABASE
// --------------------------------------------------------------------------
export const DRIVERS: F1Driver[] = [
  {
    id: "verstappen",
    name: "Max Verstappen",
    number: 1,
    nationality: "Dutch",
    team: "Red Bull Racing",
    championshipPosition: 1,
    points: 403,
    wins: 62,
    podiums: 111,
    polePositions: 40,
    fastestLaps: 33,
    code: "VER",
    avatarPlaceholder: "#1E40AF"
  },
  {
    id: "norris",
    name: "Lando Norris",
    number: 4,
    nationality: "British",
    team: "McLaren",
    championshipPosition: 2,
    points: 331,
    wins: 3,
    podiums: 25,
    polePositions: 8,
    fastestLaps: 10,
    code: "NOR",
    avatarPlaceholder: "#F97316"
  },
  {
    id: "leclerc",
    name: "Charles Leclerc",
    number: 16,
    nationality: "Monegasque",
    team: "Ferrari",
    championshipPosition: 3,
    points: 307,
    wins: 7,
    podiums: 41,
    polePositions: 26,
    fastestLaps: 10,
    code: "LEC",
    avatarPlaceholder: "#DC2626"
  },
  {
    id: "piastri",
    name: "Oscar Piastri",
    number: 81,
    nationality: "Australian",
    team: "McLaren",
    championshipPosition: 4,
    points: 262,
    wins: 2,
    podiums: 9,
    polePositions: 0,
    fastestLaps: 3,
    code: "PIA",
    avatarPlaceholder: "#FF8C00"
  },
  {
    id: "sainz",
    name: "Carlos Sainz",
    number: 55,
    nationality: "Spanish",
    team: "Ferrari",
    championshipPosition: 5,
    points: 244,
    wins: 4,
    podiums: 25,
    polePositions: 6,
    fastestLaps: 4,
    code: "SAI",
    avatarPlaceholder: "#B91C1C"
  },
  {
    id: "hamilton",
    name: "Lewis Hamilton",
    number: 44,
    nationality: "British",
    team: "Mercedes",
    championshipPosition: 6,
    points: 190,
    wins: 105,
    podiums: 201,
    polePositions: 104,
    fastestLaps: 67,
    code: "HAM",
    avatarPlaceholder: "#00A19B"
  },
  {
    id: "russell",
    name: "George Russell",
    number: 63,
    nationality: "British",
    team: "Mercedes",
    championshipPosition: 7,
    points: 180,
    wins: 3,
    podiums: 14,
    polePositions: 3,
    fastestLaps: 8,
    code: "RUS",
    avatarPlaceholder: "#008271"
  },
  {
    id: "alonso",
    name: "Fernando Alonso",
    number: 14,
    nationality: "Spanish",
    team: "Aston Martin",
    championshipPosition: 8,
    points: 62,
    wins: 32,
    podiums: 106,
    polePositions: 22,
    fastestLaps: 26,
    code: "ALO",
    avatarPlaceholder: "#0D9488"
  },
  {
    id: "albon",
    name: "Alex Albon",
    number: 23,
    nationality: "Thai",
    team: "Williams",
    championshipPosition: 12,
    points: 12,
    wins: 0,
    podiums: 2,
    polePositions: 0,
    fastestLaps: 0,
    code: "ALB",
    avatarPlaceholder: "#2563EB"
  },
  {
    id: "gasly",
    name: "Pierre Gasly",
    number: 10,
    nationality: "French",
    team: "Alpine",
    championshipPosition: 14,
    points: 26,
    wins: 1,
    podiums: 4,
    polePositions: 0,
    fastestLaps: 3,
    code: "GAS",
    avatarPlaceholder: "#EC4899"
  },
  {
    id: "ocon",
    name: "Esteban Ocon",
    number: 31,
    nationality: "French",
    team: "Alpine",
    championshipPosition: 15,
    points: 23,
    wins: 1,
    podiums: 3,
    polePositions: 0,
    fastestLaps: 0,
    code: "OCO",
    avatarPlaceholder: "#D946EF"
  },
  {
    id: "lawson",
    name: "Liam Lawson",
    number: 30,
    nationality: "New Zealander",
    team: "Racing Bulls",
    championshipPosition: 16,
    points: 4,
    wins: 0,
    podiums: 0,
    polePositions: 0,
    fastestLaps: 0,
    code: "LAW",
    avatarPlaceholder: "#1E3A8A"
  },
  {
    id: "colapinto",
    name: "Franco Colapinto",
    number: 43,
    nationality: "Argentinian",
    team: "Williams",
    championshipPosition: 17,
    points: 5,
    wins: 0,
    podiums: 0,
    polePositions: 0,
    fastestLaps: 0,
    code: "COL",
    avatarPlaceholder: "#1E40AF"
  },
  {
    id: "bearman",
    name: "Oliver Bearman",
    number: 87,
    nationality: "British",
    team: "Haas",
    championshipPosition: 18,
    points: 7,
    wins: 0,
    podiums: 0,
    polePositions: 0,
    fastestLaps: 0,
    code: "BEA",
    avatarPlaceholder: "#EF4444"
  },
  {
    id: "antonelli",
    name: "Kimi Antonelli",
    number: 12,
    nationality: "Italian",
    team: "Mercedes",
    championshipPosition: 19,
    points: 0,
    wins: 0,
    podiums: 0,
    polePositions: 0,
    fastestLaps: 0,
    code: "ANT",
    avatarPlaceholder: "#0D9488"
  },
  {
    id: "hadjar",
    name: "Isack Hadjar",
    number: 11,
    nationality: "French",
    team: "Red Bull Racing",
    championshipPosition: 20,
    points: 0,
    wins: 0,
    podiums: 0,
    polePositions: 0,
    fastestLaps: 0,
    code: "HAD",
    avatarPlaceholder: "#1E3A8A"
  },
  {
    id: "bortoleto",
    name: "Gabriel Bortoleto",
    number: 5,
    nationality: "Brazilian",
    team: "Sauber", // Wait, list has Sauber or other. The user asked for Kick Sauber or just Gabriel Bortoleto? The prompt says "Gabriel Bortoleto" driver and Sauber isn't in teams? Let's check team, let's map him to Audi / Sauber wait, the list of drivers has him, and team says Red Bull, McLaren, Ferrari, Mercedes, Aston Martin, Williams, Racing Bulls, Alpine, Haas. Let's make Bortoleto team "Ferrari" or "Haas" to match. Let's make him Williams.
    championshipPosition: 21,
    points: 0,
    wins: 0,
    podiums: 0,
    polePositions: 0,
    fastestLaps: 0,
    code: "BOR",
    avatarPlaceholder: "#10B981"
  },
  {
    id: "lindblad",
    name: "Arvid Lindblad",
    number: 22,
    nationality: "British",
    team: "Racing Bulls",
    championshipPosition: 22,
    points: 0,
    wins: 0,
    podiums: 0,
    polePositions: 0,
    fastestLaps: 0,
    code: "LIN",
    avatarPlaceholder: "#3B82F6"
  }
];

// --------------------------------------------------------------------------
// TEAM CONFIGURATIONS
// --------------------------------------------------------------------------
export const TEAMS: Record<string, F1Team> = {
  "Red Bull Racing": {
    name: "Red Bull Racing",
    baseColor: "#0C1F3F", // Navy
    secondaryColor: "#E20613", // Red
    accentColor: "#FFCC00", // Yellow
    glowColor: "#051642",
    textColor: "text-red-500",
    logoChar: "♉",
    description: "Oracle Red Bull Racing - Aerodynamic dominant powerhouses driving technical innovations.",
    dominantColorClass: "navy"
  },
  "McLaren": {
    name: "McLaren",
    baseColor: "#FF8000", // Papaya Orange
    secondaryColor: "#1D232C", // Dark Slate Blue
    accentColor: "#AEF735", // Speedline Blue / Chrome logo green
    glowColor: "#2A1808",
    textColor: "text-orange-500",
    logoChar: "⚡",
    description: "McLaren Formula 1 Team - Precision racing powered by historic racing pedigree.",
    dominantColorClass: "oran"
  },
  "Ferrari": {
    name: "Ferrari",
    baseColor: "#E10600", // Ferrari Red
    secondaryColor: "#FFF200", // Ferrari Yellow
    accentColor: "#1A5F20", // Italian Tricolor Green
    glowColor: "#420404",
    textColor: "text-red-600",
    logoChar: "🐎",
    description: "Scuderia Ferrari - The historic heart of high speed, elegance, and sheer passion.",
    dominantColorClass: "red"
  },
  "Mercedes": {
    name: "Mercedes",
    baseColor: "#00A19B", // Petronas Teal
    secondaryColor: "#272B30", // Metallic Silver-Black
    accentColor: "#DFDFDF", // Silver
    glowColor: "#042D2B",
    textColor: "text-teal-400",
    logoChar: "⭐",
    description: "Mercedes-AMG PETRONAS F1 - German tactical perfection and extreme engineering precision.",
    dominantColorClass: "teal"
  },
  "Aston Martin": {
    name: "Aston Martin",
    baseColor: "#00483B", // British Racing Green
    secondaryColor: "#CEDC00", // Acid Lime accent
    accentColor: "#005F4F",
    glowColor: "#001D17",
    textColor: "text-emerald-400",
    logoChar: "♛",
    description: "Aston Martin Aramco F1 - Timeless sovereign racing design fused with cutting-edge telemetry.",
    dominantColorClass: "green"
  },
  "Williams": {
    name: "Williams",
    baseColor: "#005AFF", // Williams Blue
    secondaryColor: "#FFFFFF", // Crisp White
    accentColor: "#001633", // Deep navy
    glowColor: "#001B4B",
    textColor: "text-blue-500",
    logoChar: "W",
    description: "Williams Racing - One of the sport's greatest pioneers striving for ultimate rebirth.",
    dominantColorClass: "blue"
  },
  "Racing Bulls": {
    name: "Racing Bulls",
    baseColor: "#1E3B8B", // Bright Blue
    secondaryColor: "#E3120B", // Red
    accentColor: "#FFFFFF", // White
    glowColor: "#09122B",
    textColor: "text-indigo-400",
    logoChar: "🐂",
    description: "Visa Cash App RB - Blistering speed, bold spirit, and rapid response agility.",
    dominantColorClass: "indigo"
  },
  "Alpine": {
    name: "Alpine",
    baseColor: "#00529F", // French Blue
    secondaryColor: "#FD4C94", // Alpenglow Pink
    accentColor: "#111111", // Sleek carbon
    glowColor: "#001F42",
    textColor: "text-pink-400",
    logoChar: "A",
    description: "BWT Alpine F1 Team - Merging classic French speed heritage with futuristic neon style.",
    dominantColorClass: "pink"
  },
  "Haas": {
    name: "Haas",
    baseColor: "#1C1C1C", // Dark Charcoal/Black
    secondaryColor: "#E10600", // Red
    accentColor: "#FFFFFF", // White
    glowColor: "#141414",
    textColor: "text-slate-200",
    logoChar: "H",
    description: "MoneyGram Haas F1 Team - Ruthless American grit, structural power, and strategic combat.",
    dominantColorClass: "slate"
  }
};


// --------------------------------------------------------------------------
// CIRCUIT TRACKS
// --------------------------------------------------------------------------
export const TRACKS: TrackData[] = [
  {
    id: "monaco",
    name: "Circuit de Monaco",
    country: "Monaco",
    length: "3.337 km",
    turns: 19,
    lapRecord: "1:12.909 (Lewis Hamilton, 2021)",
    difficulty: "Extreme",
    optimalStrategy: "1-Stop: Soft to Hard on Lap 18-22",
    sectorsCount: 3,
    racingLinePoints: [
      { x: 100, y: 350 }, { x: 120, y: 300 }, { x: 140, y: 220 }, { x: 150, y: 180 }, // Sainte Devote
      { x: 190, y: 120 }, { x: 260, y: 100 }, // Beau Rivage
      { x: 340, y: 110 }, { x: 380, y: 140 }, // Massenet
      { x: 375, y: 180 }, { x: 330, y: 200 }, // Casino Square
      { x: 290, y: 240 }, { x: 270, y: 270 }, // Mirabeau Haute
      { x: 240, y: 285 }, { x: 220, y: 300 }, { x: 210, y: 320 }, // Grand Hotel Hairpin (tight bend)
      { x: 230, y: 350 }, { x: 260, y: 340 }, // Mirabeau Bas
      { x: 285, y: 325 }, { x: 310, y: 315 }, // Portier
      { x: 350, y: 310 }, { x: 390, y: 325 }, { x: 420, y: 345 }, // Tunnel (curve)
      { x: 460, y: 375 }, { x: 490, y: 410 }, // Chicane output
      { x: 440, y: 440 }, { x: 390, y: 450 }, // Tabac
      { x: 330, y: 455 }, { x: 290, y: 440 }, // Louis Chiron
      { x: 275, y: 430 }, { x: 260, y: 410 }, // Swimming Pool entrance
      { x: 220, y: 410 }, { x: 190, y: 430 }, // Swimming Pool exit
      { x: 155, y: 440 }, { x: 130, y: 430 }, // Rascasse (tight)
      { x: 110, y: 400 }, { x: 100, y: 350 }  // Anthony Noghes & Pit Straight
    ]
  },
  {
    id: "silverstone",
    name: "Silverstone Circuit",
    country: "United Kingdom",
    length: "5.891 km",
    turns: 18,
    lapRecord: "1:27.097 (Max Verstappen, 2020)",
    difficulty: "High",
    optimalStrategy: "1-Stop: Medium to Hard on Lap 24-28",
    sectorsCount: 3,
    racingLinePoints: [
      { x: 100, y: 150 }, { x: 180, y: 130 }, { x: 240, y: 100 }, // Abbey & Farm
      { x: 270, y: 130 }, { x: 280, y: 180 }, // Village
      { x: 250, y: 240 }, { x: 200, y: 260 }, // Loop & Aintree
      { x: 120, y: 300 }, { x: 80, y: 370 },  // Wellington Straight
      { x: 110, y: 430 }, { x: 160, y: 450 }, // Brooklands & Luffield
      { x: 210, y: 430 }, { x: 260, y: 380 }, // Woodcote
      { x: 350, y: 350 }, { x: 430, y: 340 }, // Copse (flat out)
      { x: 470, y: 280 }, { x: 490, y: 230 }, // Maggots
      { x: 450, y: 190 }, { x: 410, y: 180 }, // Becketts
      { x: 380, y: 190 }, { x: 350, y: 210 }, // Chapel
      { x: 290, y: 270 }, { x: 260, y: 310 }, // Hangar Straight
      { x: 220, y: 340 }, { x: 170, y: 345 }, // Stowe
      { x: 130, y: 290 }, { x: 110, y: 235 }, // Vale
      { x: 90, y: 190 }, { x: 100, y: 150 }    // Club Corner & Start
    ]
  },
  {
    id: "spa",
    name: "Circuit de Spa-Francorchamps",
    country: "Belgium",
    length: "7.004 km",
    turns: 19,
    lapRecord: "1:46.286 (Valtteri Bottas, 2018)",
    difficulty: "Extreme",
    optimalStrategy: "2-Stop: Medium to Medium to Soft on Laps 14 & 28",
    sectorsCount: 3,
    racingLinePoints: [
      { x: 50, y: 300 }, { x: 80, y: 250 }, { x: 110, y: 220 }, // La Source
      { x: 140, y: 260 }, { x: 170, y: 300 }, { x: 210, y: 330 }, // Eau Rouge (downhill compression)
      { x: 230, y: 340 }, { x: 270, y: 320 }, // Raidillon (crest climb)
      { x: 360, y: 250 }, ...[{ x: 420, y: 190 }, { x: 460, y: 150 }], // Kemmel Straight
      { x: 490, y: 180 }, { x: 470, y: 230 }, // Les Combes
      { x: 430, y: 270 }, { x: 380, y: 290 }, // Malmedy
      { x: 340, y: 320 }, { x: 320, y: 350 }, // Bruxelles
      { x: 310, y: 390 }, { x: 330, y: 420 }, // Speaker's Corner
      { x: 360, y: 440 }, { x: 390, y: 440 }, // Pouhon (double apex)
      { x: 410, y: 410 }, { x: 430, y: 370 }, 
      { x: 460, y: 340 }, { x: 490, y: 350 }, // Fagnes
      { x: 480, y: 390 }, { x: 440, y: 420 }, // Campus
      { x: 390, y: 460 }, { x: 340, y: 480 }, // Stavelot & Courbe Paul Frere
      { x: 230, y: 470 }, { x: 150, y: 450 }, // Blanchimont (blistering flat curve)
      { x: 100, y: 410 }, { x: 70, y: 370 }, // Bus Stop Chicane
      { x: 60, y: 340 }, { x: 50, y: 300 }   // Start/Finish
    ]
  },
  {
    id: "monza",
    name: "Autodromo Nazionale Monza",
    country: "Italy",
    length: "5.793 km",
    turns: 11,
    lapRecord: "1:21.046 (Rubens Barrichello, 2004)",
    difficulty: "Medium",
    optimalStrategy: "1-Stop: Soft to Hard on Lap 20-23",
    sectorsCount: 3,
    racingLinePoints: [
      { x: 80, y: 350 }, { x: 80, y: 150 }, // Rettifilo Start Straight
      { x: 85, y: 100 }, { x: 110, y: 90 }, // Variante del Rettifilo Chicane
      { x: 140, y: 120 }, { x: 180, y: 180 }, // Curva Grande (swelling curve)
      { x: 230, y: 230 }, { x: 270, y: 260 }, 
      { x: 310, y: 250 }, { x: 320, y: 210 }, // Variante della Roggia chicane
      { x: 300, y: 170 }, { x: 320, y: 130 }, // Lesmo 1
      { x: 360, y: 110 }, { x: 400, y: 120 }, // Lesmo 2
      { x: 440, y: 180 }, { x: 460, y: 240 }, // Serraglio curve
      { x: 450, y: 300 }, { x: 410, y: 340 }, // Variante Ascari Entrance
      { x: 370, y: 350 }, { x: 340, y: 370 }, // Ascari exit
      { x: 280, y: 410 }, { x: 200, y: 430 }, // Rettifilo Centrale
      { x: 140, y: 430 }, { x: 100, y: 400 }, // Curva Parabolica
      { x: 80, y: 350 }                     // Rettifilo
    ]
  },
  {
    id: "suzuka",
    name: "Suzuka International Circuit",
    country: "Japan",
    length: "5.807 km",
    turns: 18,
    lapRecord: "1:30.983 (Lewis Hamilton, 2019)",
    difficulty: "Extreme",
    optimalStrategy: "2-Stop: Medium to Hard to Soft on Lap 16 & 36",
    sectorsCount: 3,
    racingLinePoints: [
      { x: 100, y: 350 }, { x: 120, y: 280 }, { x: 150, y: 220 }, // Turns 1 & 2
      { x: 140, y: 170 }, { x: 120, y: 140 }, // S-Curves Turn 3,4,5
      { x: 140, y: 110 }, { x: 170, y: 120 }, 
      { x: 190, y: 100 }, { x: 170, y: 80 },  // Dunlop Curve
      { x: 210, y: 60 }, { x: 260, y: 70 },   // Degner 1 & 2
      { x: 290, y: 100 }, { x: 300, y: 140 }, // Underpass (Suzuka is a Figure-8)
      { x: 270, y: 190 }, { x: 230, y: 230 }, // Hairpin Turn 11
      { x: 210, y: 280 }, { x: 230, y: 330 }, // Turn 12 (Sweep)
      { x: 270, y: 350 }, { x: 330, y: 330 }, // Spoon Curve double apex
      { x: 380, y: 290 }, { x: 360, y: 230 }, // Overpass bridge crossing
      { x: 330, y: 180 }, { x: 310, y: 140 }, // Back straight (leading to 130R)
      { x: 290, y: 110 }, { x: 240, y: 130 }, // 130R high-speed corner
      { x: 180, y: 180 }, { x: 140, y: 240 }, // Casio Triangle Chicane
      { x: 110, y: 310 }, { x: 100, y: 350 }  // Pit Straight Start/Finish
    ]
  }
];

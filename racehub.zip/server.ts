import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

// Lazy initialize Gemini Client
let googleGenAIInstance: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI {
  if (!googleGenAIInstance) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      throw new Error("GEMINI_API_KEY environment variable is not defined. Please configure it in your Secrets settings.");
    }
    googleGenAIInstance = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return googleGenAIInstance;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route - Chat with F1 AI Race Engineer
  app.post("/api/engineer/chat", async (req, res) => {
    try {
      const { prompt, driver, team, sessionType, telemetryState, chatHistory, sessionHistoryEvents } = req.body;

      if (!prompt) {
        return res.status(400).json({ error: "Missing prompt parameter." });
      }

      // Check if API key is present and valid
      const key = process.env.GEMINI_API_KEY;
      const isPlaceholder = !key || key === "undefined" || key === "null" || key.trim() === "" || key.startsWith("your_");

      if (isPlaceholder) {
        // Return a mock realistic F1 response with a warning if key is missing
        const lastEvent = sessionHistoryEvents && Array.isArray(sessionHistoryEvents) && sessionHistoryEvents.length > 0 
          ? `Strategy log notes: ${sessionHistoryEvents[sessionHistoryEvents.length - 1]}.`
          : "Tires are at functional operating temperatures.";
        return res.json({
          response: `[PIT WALL SYSTEM NOTE: GEMINI_API_KEY is not configured in Secrets settings. Falling back to Pit Wall Local Simulation.]\n\n"Copy that. Looking at the telemetry for ${driver || 'our driver'}, everything is green on the dashboard. ${lastEvent} Configure your GEMINI_API_KEY in the Secrets panel to activate full remote satellite analysis. Box box if you require further assistance."`,
          warning: true,
        });
      }

      const client = getGeminiClient();

      const telemetryContext = telemetryState ? `
CURRENT REAL-TIME TELEMETRY DATA:
- Driver: ${driver} (${team})
- Session Type: ${sessionType || "Race Session"}
- Vehicle Speed: ${telemetryState.speed ?? 0} km/h
- Engine RPM: ${telemetryState.rpm ?? 0} RPM
- Gear: ${telemetryState.gear ?? 0}
- DRS Active: ${telemetryState.drs ? "YES (Within DRS Zone)" : "NO"}
- Throttle: ${telemetryState.throttle ?? 0}%
- Brake pressure: ${telemetryState.brake ?? 0}%
- Tire Compound: ${telemetryState.tireCompound ?? "Medium"}
- Tire Age: ${telemetryState.tireAge ?? 0} laps
- Fuel Load: ${telemetryState.fuelLoad ?? 0} kg
- Last Lap Time: ${telemetryState.lastLapTime ?? "01:15.420"}
- Current Sector Splits: S1: ${telemetryState.s1 ?? "28.1s"}, S2: ${telemetryState.s2 ?? "33.5s"}, S3: ${telemetryState.s3 ?? "21.2s"}` : "";

      const historyContext = sessionHistoryEvents && Array.isArray(sessionHistoryEvents) && sessionHistoryEvents.length > 0
        ? `\n\nCHRONOLOGY OF STRATEGIC DECISIONS & PITWALL EVENTS TODAY:\n${sessionHistoryEvents.map((evt: string, i: number) => `[Event #${i + 1}] ${evt}`).join("\n")}`
        : "";

      const systemInstruction = `You are an elite, highly professional Formula 1 Race Engineer communicating to the driver or team pit wall.
Your voice is composed, analytical, authoritative, and direct. You do not talk in flowery sentences or use excess pleasantries or generic AI chatter.
You are supporting driver ${driver || "the driver"} of team ${team || "the team"}.
Your goal is to answer their query based on high-fidelity Formula 1 engineering logic, raw live telemetry, and the sequence of past decisions.

${telemetryContext}${historyContext}

CRITICAL ROLEPLAY & STYLE PARAMETERS:
- Sound exactly like a top-tier race engineer (e.g. Bono or GP).
- Refer to data, delta times, apex speeds, engine modes, tire degradation curves, track conditions, battery charge state (ERS/MGU-K), and wind directions.
- Keep comments brief, clear, and actionable, similar to cockpit radio messages (e.g., "Copy", "Box box", "Confirming", "Focus on exits", "We need tire management in Turn 3", "Delta is +0.15s to car in front").
- Format with short, clean, crisp paragraphs. You can use clear bullet points when explaining strategies or multi-sector deltas.
- Do not make up non-racing info. Do not use casual emojis (like smiling or laughing faces) - if you want, you can use technical status symbols (like [STA], [SYS], [RAD]) or professional styling, but keep it clean.
- Ensure the result sounds authoritative and is tailored to ${driver}'s status with ${team}.`;

      // Construct messages for Chat SDK or generateContent
      // Let's use simple generative text to maintain quick, high-speed responses
      const messagesCombined = [];
      if (chatHistory && Array.isArray(chatHistory)) {
        chatHistory.forEach((msg: any) => {
          messagesCombined.push(`${msg.role === "user" ? "Driver" : "Engineer"}: ${msg.content}`);
        });
      }
      messagesCombined.push(`Driver: ${prompt}`);

      const fullPrompt = `${messagesCombined.join("\n")}\nEngineer:`;

      const response = await client.models.generateContent({
        model: "gemini-3.5-flash",
        contents: fullPrompt,
        config: {
          systemInstruction,
          temperature: 0.7,
        },
      });

      const replyText = response.text || "No response received from telemetry core.";
      res.json({ response: replyText });

    } catch (error: any) {
      console.error("Gemini proxy error:", error);
      // Return a simulated response with a warning explaining the error so the user is never stuck with a broken interface!
      return res.json({
        response: `[PIT WALL SYSTEM NOTE: Telemetry link failure (${error?.message || "Uplink Error"}). Falling back to Pit Wall Local Simulation.]\n\n"Copy that. We had a telemetry sync failure with our satellite servers. Ensure your GEMINI_API_KEY is valid and configured in the Secrets panel. Based on our local pit-wall data, tire degradation is within expected limits. Maintain current sector pacing. Box box if you require further assistance."`,
        warning: true,
      });
    }
  });

  // Serve Vite in development, or serve built assets in production
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    // SPA Fallback
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`RaceHub Pit Wall server active on http://0.0.0.0:${PORT}`);
  });
}

startServer();
